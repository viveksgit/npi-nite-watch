/* globals WScript: true */

(function () {
    var WshShell = WScript.CreateObject('WScript.Shell');
    
    var username = WScript.arguments(0);
    var password = WScript.arguments(1);

    //Troubleshooting username/password values
    // WshShell.Popup(username);
    // WshShell.Popup(password);

    WshShell.SendKeys(username.substring(1));
    WshShell.SendKeys('{TAB}');
    WshShell.SendKeys(password.substring(0, password.length - 1));
    WshShell.SendKeys('{ENTER}');
})();