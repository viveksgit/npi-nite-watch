exports.command = function loginSTS2(username, password, callback) {
    var self = this;
    var platform = process.platform.toLowerCase();

    self.pause(5000);

    if (platform.match('darwin')) {
        self.perform(function () {
            require('child_process').spawn('applescript', ['sendKeysMac.scpt', '"' + username + ' ' + password + '"']);
            self.pause(4000);
        });
    } else {
        self.perform(function () {
            require('child_process').spawn('wscript.exe', ['sendKeys.js', '"' + username + ' ' + password + '"']);
            self.pause(4000);
        });
    }

    if (typeof callback === 'function') {
        callback.call(self);
    }

    return self;
};