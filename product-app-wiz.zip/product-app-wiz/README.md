# product-app-wiz

#### Depends on questions
ms-reflexive-questions

## Description
Provide routing information for src applications

## Running locally
If you haven't already done so, complete the [Local Development](https://git.nmlv.nml.com/lvhub/docs/blob/master/getting-started/local-development.md) getting started guide.

Run _`npm run dev-int`_ from the root project directory.  To verify your environment is working, load the [health endpoint](http://localhost:8080/api/v1/src-reflexive-questions/health) to ensure you are receiving a successful response.

### When connecting to a local DB
Note: when connecting to the locally running micro services, remember to update the node_modules/nmlvhub-node-rds-pool/pool.js and comment out the ssl: 'Amazon RDS'

#### Unit testing
Run _`npm run build`_ from the root project directory.

#### Live changes
Locally your node service is run by [nodemon](http://nodemon.io/) so that changes are reflected immediately.  Simply make your changes and the service will automatically recycle in a matter of seconds to show you your change.

#### Prerequisite to run...

- _`node --version && npm --version`_ to ensure [Node.js](https://nodejs.org/) is correctly installed

## Routes

| AppLocation   | /BasePath       |
| :-----------: | :-------------- |
| CX            | /product-app-wiz |


#### Ports
<table>
    <tr>
        <td>:8080</td>
        <td>http</td>
    </tr>
    <tr>
        <td>:8443</td>
        <td>https</td>
    </tr>
</table>

## Getting Started

### Run Dev

1. pull in the [schema project](https://git.nmlv.nml.com/src/rds-npirq-schema), change to the localdb directory and run installdb.sh
```bash
./installdb.sh
```
2. install the latest version of the [spreadsheet](https://git.nmlv.nml.com/src/rds-npirq-version)
```bash
npm run load-build-dev
npm run seed-apps-dev
```

3. startup the app(s)

```bash
$ npm install && npm run dev
```
or
```bash
$ npm install && npm run dev-int
```

alternatively you can get all apps including the microservices started by [running a script](https://git.nmlv.nml.com/MAT1081/utils/blob/master/scripts/startNPI.sh) that launches them all at once as found.

### Run Production

```bash
$ npm run build && npm start
```
### Run Tests

```bash
npm run test
```

## Boilerplate Version [slush-pwa](https://git.nmlv.nml.com/engineering/slush-pwa) v0.0.2

#### Debugging
To debug with chrome developer tools load the [node-inspector](http://localhost:8081/?ws=localhost:8081&port=5858).

## Documentation
_(Coming Soon)_

## API
#### [Swagger Schema](swagger.json)

#### Apigee Documentation _(Coming soon)_

_* For more information on [Swagger](http://swagger.io/) schema format see their [specification documentation](http://swagger.io/specification/)._

## Release History
_(Nothing yet)_


## Local Dev Setup...
1. pull in the schema project, change to the localdb directory and run installdb.sh```$ ./installdb.sh```
