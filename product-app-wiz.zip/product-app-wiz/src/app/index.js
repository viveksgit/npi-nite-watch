import React from 'react'
import {render} from 'react-dom'
import {AppContainer} from 'react-hot-loader'
import ensurePolyfills from './utils/ensure-polyfills'
import Entry from './entry'
import {BrowserRouter, Route} from 'react-router-dom'

// JWT SSO Authentication...
import nmAdal from './tokens'

// Turn this on for logging
nmAdal.authContext.log = console.log

const renderEntry = Component => ensurePolyfills(() => {
  nmAdal.isAuthenticated().then(() => {
    if (!nmAdal.authContext.isCallback(window.location.hash)) {
      // Having both of these checks is to prevent having a token in localstorage, but no user. Relates to issue #471
      if (!nmAdal.getBothTokens() || !nmAdal.authContext.getCachedUser()) {
        nmAdal.authContext.login()
      } else {
        nmAdal.getBothTokens()
        .then((tokenCont) => {
          // only if we have both tokens will we render this component
          const app = document.getElementById('app')
          if (window.newrelic) {
            window.newrelic.setCustomAttribute('nmUniqueId', window.__STATE__.meta.nmUniqueId)
          }
          render(
            <AppContainer>
              <BrowserRouter>
                <Route path='/product-app-wiz/:productAppId/section/:sectionId' render={(props) => {
                  return (<Component productApplicationId={Number(props.match.params.productAppId)} activeSectionId={props.match.params.sectionId} />)
                }} />
              </BrowserRouter>
            </AppContainer>, app)
        })
      }
    }
  })
})

renderEntry(Entry)

if (module.hot) {
  module.hot.accept('./entry', () => {
    const RootContainer = require('./entry').default
    renderEntry(RootContainer)
  })
}
