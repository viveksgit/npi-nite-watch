/**
 * JWT SSO Authentication...
 * Taken from (Interactive Pattern Reference Pattern): React app.
 * https://github.nml.com/nm/interactive-pattern-reference-implementation/blob/auth/react/src/js/utils/nm-adal.js
 */
/*
 This will be a NM shared module at time point....
 */

 import axios from 'axios'

 axios.interceptors.response.use(undefined, err => {
   if (err.response.status === 401 && err.response.config && !err.response.config.__isRetryRequest) {
     err.response.config.__isRetryRequest = true
     return getBothTokens().then((tokenCont) => {
       axios.defaults.headers.common['Authorization'] = `Bearer ${tokenCont.id_token}`
       err.config.headers.Authorization = `Bearer ${tokenCont.id_token}`
       axios.defaults.headers.common['access_token'] = `Bearer ${tokenCont.access_token}`
       // axios(err.config).then(resolve, reject);
     })
   }
   throw err
 })

// DTM: added this since config isn't defined in their module
 const parsedAdal = JSON.parse(adal)
  // adal is set in the get-app
 var AuthenticationContext = require('adal-angular') // eslint-disable-line import/no-webpack-loader-syntax
  // TODO ask Drew about the expose loader and why it was used
  // var AuthenticationContext = require('expose-loader?AuthenticationContext!adal-angular'); // eslint-disable-line import/no-webpack-loader-syntax
 var _adal = (!window.__EXTRA_CONFIG__)
  ? new AuthenticationContext(parsedAdal)
  : {
    config: {
      loginResourse: 'NPI12345'
    },
    getUser: () => {

    },
    handleWindowCallback: () => {

    },
    getCachedToken: (myvar) => {
      return window.__EXTRA_CONFIG__.accessToken
    },
    acquireToken: (source, cb) => {
      const token = (source.indexOf('graph') >= 0) ? window.__EXTRA_CONFIG__.graphToken : window.__EXTRA_CONFIG__.accessToken
      cb(undefined, token)
    },
    isCallback: (hash) => {
      console.log('MOCK->is callback')
      return false
    },
    getCachedUser: () => {
      return {}
    }
  }

// stupid fix...
 _adal.getUser(() => {
  // do nothing because we just needed adal._user to be populated so
  // it doesn't do a hard redirect.
 })

 var refreshToken = function () {
   return new Promise((resolve, reject) => {
     _adal.acquireToken(_adal.config.loginResource, (error, tokenOut) => {
       if (error) {
         _adal.login()
         reject(error)
       }
       axios.defaults.headers.common['Authorization'] = `Bearer ${tokenOut}`
       resolve(tokenOut)
     })
   })
 }

 var getToken = function () {
   return new Promise((resolve, reject) => {
     var token = _adal.getCachedToken(_adal.config.loginResource)

     if (token) {
       axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
       return resolve(token)
     }

     refreshToken().then(token => resolve(token)).catch(error => reject(error))
   })
 }

// DTM: added this from JWT-Files repo
 var getGraphToken = function () {
   return new Promise((resolve, reject) => {
     return _adal.acquireToken('https://graph.windows.net', function (error, token) {
       if (error) {
         console.log('getGraphtokenerror %o', error)
         reject(error)
       }
       axios.defaults.headers.common['access_token'] = `Bearer ${token}`
       return resolve(token)
     })
   })
 }

 var isAuthenticated = function () {
   return getToken().then(token => true)
 }

// DTM: This prevents the infinite loop of auth requests
 _adal.handleWindowCallback()

 var tokenRefreshInterval = setInterval(getToken, 60000)

 const getBothTokens = function () {
   return new Promise((resolve, reject) => {
     getToken().then(token => {
       getGraphToken().then(graphToken => {
         var tokenCont = {
           id_token: token,
           access_token: graphToken
         }
         resolve(tokenCont)
       })
     })
   })
 }

 module.exports = {
   isAuthenticated: isAuthenticated,
   getToken: getToken,
   getGraphToken: getGraphToken, // DTM: added this from JWT-Files repo
  // refreshToken: refreshToken, // DTM: added this because we need it for setting the token in the headers for the axios calls
   authContext: _adal, // DTM: added this so we can use the auth context outside of this component for the auto refresh
   getBothTokens: getBothTokens
 }
