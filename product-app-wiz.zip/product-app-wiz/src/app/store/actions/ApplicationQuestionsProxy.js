import axios from 'axios'

import {
  FETCH_SECTIONS, FETCH_SECTIONS_COMPLETE, FETCH_SECTIONS_ERROR
  , FETCH_SECTION_QUESTIONS, FETCH_SECTION_QUESTION_COMPLETE, FETCH_SECTION_QUESTION_ERROR
  , QUESTION_ANSWER_CHANGE, QUESTION_ANSWER_CHANGE_COMPLETE, QUESTION_ANSWER_CHANGE_ERROR, QUESTION_ANSWER_CHANGE_VALIDATION_ERROR
  , REFLEXIVE_OPTION_ANSWER_CHANGE, FETCH_CATEGORIES, FETCH_CATEGORIES_COMPLETE, FETCH_CATEGORIES_ERROR
} from './ActionTypes'

class ApplicationQuestionsProxy {
  getQuestions (dispatch, productAppId, sectionId) {
    dispatch({type: FETCH_SECTION_QUESTIONS})
    return axios.get(`/product-app-wiz/api/productApp/${productAppId}/sections/${sectionId}`)
      .then(reply => dispatch({type: FETCH_SECTION_QUESTION_COMPLETE, result: reply.data}))
      .catch(reply => dispatch({type: FETCH_SECTION_QUESTION_ERROR, result: reply.data}))
  }

  getRequiredSections (dispatch, productAppId) {
    dispatch({type: FETCH_SECTIONS})
    return axios.get(`/product-app-wiz/api/productApp/${productAppId}/sections`)
      .then(reply => dispatch({type: FETCH_SECTIONS_COMPLETE, result: reply.data}))
      .catch(reply => dispatch({type: FETCH_SECTIONS_ERROR, result: reply.data}))
  }

  getRequiredCategories (dispatch, productAppId) {
    dispatch({type: FETCH_CATEGORIES})
    return axios.get(`/product-app-wiz/api/productApp/${productAppId}/categories`)
      .then(reply => { console.log('reply', reply); return reply })
      .then((reply) => dispatch({type: FETCH_CATEGORIES_COMPLETE, result: reply.data}))
      .catch(reply => dispatch({type: FETCH_CATEGORIES_ERROR, result: reply.data}))
  }

  upsertAnswer (dispatch, productAppId, answer) {
        // removing properties from the answer since we don't care about them, and will
        // cause some confusion
    delete answer.productAppId
    delete answer.reflexiveQuestions // FIXME this should not be in this answer object to begin with
    console.log('ApplicationQuestionsProxy.upsertAnswer() answer ->', answer)
    const dispatchReturn = dispatch({type: QUESTION_ANSWER_CHANGE, initialAnswer: answer})
    return axios.put(`/product-app-wiz/api/productApp/${productAppId}/answers`, answer)
      .then(reply => dispatch({type: QUESTION_ANSWER_CHANGE_COMPLETE, result: reply.data}))
      .then(dispatched => {
        console.log('ApplicationQuestionsProxy.upsertAnswer() dispatched ->', dispatched)
        if (dispatched.result.fullAnswer && dispatched.result.reflexive) {
          dispatch({ type: REFLEXIVE_OPTION_ANSWER_CHANGE, data: dispatched.result })
        }
        return dispatched
      })
      .catch(reply => {
        console.log('applicationQuestionsProxy.upsertAnswer() ERROR!', reply)
        if (reply.response.status === 400 &&
            reply.response.data &&
            reply.response.data.fieldValidationErrors) {
          return dispatch({
            type: QUESTION_ANSWER_CHANGE_VALIDATION_ERROR,
            sectionQuestionRelId: answer.sectionQuestionRelId,
            fieldValidationErrors: reply.response.data.fieldValidationErrors})
        }
        return dispatch({type: QUESTION_ANSWER_CHANGE_ERROR, sectionQuestionRelId: answer.sectionQuestionRelId, error: reply})
      })
  }
}

export default new ApplicationQuestionsProxy()
