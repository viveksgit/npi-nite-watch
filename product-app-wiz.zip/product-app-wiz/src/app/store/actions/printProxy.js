import axios from 'axios'

class PrintProxy {
  // There may be a better option to cache this in redux, but this works for now,
  // and it seems a little akward to connect up the components for components that use this
  getPdf (productAppId) {
    return axios.get(`/product-app-wiz/api/pdfGeneration/${productAppId}`)
  }
}

export default new PrintProxy()
