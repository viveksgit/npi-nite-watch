import axios from 'axios'

const optionsMap = new Map()

class ValsProxy {
  // There may be a better option to cache this in redux, but this works for now,
  // and it seems a little akward to connect up the components for components that use this
  getOptions (url) {
    if (optionsMap.get(url)) {
      return Promise.resolve(optionsMap.get(url))
    } else {
      return axios.get(`/product-app-wiz${url}`)
              .then(options => {
                optionsMap.set(url, options.data)
                return options.data
              })
              .catch(error => {
                console.log('Problems fetching option values! error: ', error)
                return error
              })
    }

    return axios.get(`/product-app-wiz${url}`)
  }
}

export default new ValsProxy()
