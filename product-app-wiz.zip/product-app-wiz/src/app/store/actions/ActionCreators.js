const fetchOptions = {credentials: 'include'}

export const fetchInitialState = () => (dispatch) => Promise.all([
  // dispatch(fetchPeople())
  // commented to get rid of prestate loading
])
