export const getNmUniqueId = (state) => state.meta.nmUniqueId
