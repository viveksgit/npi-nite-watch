import {
  FETCH_SECTION_QUESTIONS,
  FETCH_SECTION_QUESTION_COMPLETE,
  FETCH_SECTION_QUESTION_ERROR,
  REFLEXIVE_OPTION_ANSWER_CHANGE,
  QUESTION_ANSWER_CHANGE,
  QUESTION_ANSWER_CHANGE_COMPLETE,
  QUESTION_ANSWER_CHANGE_VALIDATION_ERROR} from '../actions/ActionTypes'

import {injectReflexiveQuestions} from '../../utils/injectReflexiveQuestions'

export default (state = {}, action) => {
  // console.log('sectionQuestionListing state ->', state)
  // console.log('sectionQuestionListing action ->', action)
  switch (action.type) {
    case FETCH_SECTION_QUESTIONS:
      return Object.assign({}, {state: 'FETCHING'})
    case FETCH_SECTION_QUESTION_COMPLETE:
      return Object.assign({}, {state: 'COMPLETE', result: action.result})
    case FETCH_SECTION_QUESTION_ERROR:
      console.log('something is very wrong!!->', action)
      return Object.assign({}, {state: 'ERROR', result: action.result})
    case REFLEXIVE_OPTION_ANSWER_CHANGE:
      // event is originally dispatched after the response from the upsert and the question that was changed
      // was reflexive and there were new questions to ask
      const newQuestionSet = injectReflexiveQuestions(state.result, action.data)
        // injecting reflexive questions based on the last response in context of the question (i.e. right after the last answer)
      return Object.assign({}, {state: 'UPDATED', result: newQuestionSet})
    case QUESTION_ANSWER_CHANGE:
      const questionUpdated = state.result.find(question => question.sectionQuestionRelId === action.initialAnswer.sectionQuestionRelId)
      questionUpdated.answer = action.initialAnswer
      return Object.assign({}, {state: 'UPDATED', result: state.result})
    case QUESTION_ANSWER_CHANGE_COMPLETE:
      // console.log('sectionQuestionListing QUESTION_ANSWER_CHANGE_COMPLETE state -> ', state)
      // console.log('sectionQuestionListing QUESTION_ANSWER_CHANGE_COMPLETE action -> ', action)
      const currentState = Array.from(state.result)
      const questionToUpdateWithAnswer = currentState.find(question => action.result.fullAnswer && (question.sectionQuestionRelId === action.result.fullAnswer.sectionQuestionRelId))
      // console.log('sectionQuestionListing QUESTION_ANSWER_CHANGE_COMPLETE questionToUpdateWithAnswer -> ', questionToUpdateWithAnswer)
      if (questionToUpdateWithAnswer) {
        questionToUpdateWithAnswer.answer = action.result.fullAnswer
        questionToUpdateWithAnswer.validationErrors = null
        questionToUpdateWithAnswer.standardizedPropertyValues = action.result.standardizedPropertyValues
      }
      // console.log('sectionQuestionListing QUESTION_ANSWER_CHANGE_COMPLETE questionToUpdateWithAnswer -> ', questionToUpdateWithAnswer)
      return Object.assign({}, {state: 'UPDATED', result: currentState})
    case QUESTION_ANSWER_CHANGE_VALIDATION_ERROR:
      const currentQuestionState = Array.from(state.result)
      const questionWithFieldValidationError = currentQuestionState.find(question => action.sectionQuestionRelId && (question.sectionQuestionRelId === action.sectionQuestionRelId))
      if (!questionWithFieldValidationError) {
        console.log(`we have some problems...the reply from the update had field validation errors, but the user is no longer on the same section!  sectionQuestionRelId: ${action.sectionQuestionRelId}`)
        return state
      }
      questionWithFieldValidationError.validationErrors = action.fieldValidationErrors
      return Object.assign({}, {state: 'UPDATED', result: currentQuestionState})
    default: return state
  }
}
