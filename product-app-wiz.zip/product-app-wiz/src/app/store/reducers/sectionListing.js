import {
  FETCH_SECTIONS,
  FETCH_SECTIONS_COMPLETE,
  FETCH_SECTIONS_ERROR} from '../actions/ActionTypes'

export default (state = {}, action) => {
  console.log('sectionListing reducer [action]', action)
  switch (action.type) {
    case FETCH_SECTIONS:
      return Object.assign({}, {state: 'FETCHING'})
    case FETCH_SECTIONS_COMPLETE:
      return Object.assign({}, {state: 'COMPLETE', result: action.result})
    case FETCH_SECTIONS_ERROR:
      return Object.assign({}, {state: 'ERROR', result: action.result})
    default: return state
  }
}
