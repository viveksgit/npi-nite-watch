export const initialState = {
  title: '/product-app-wiz',
  nmUniqueId: 'no_user',
  userName: 'no_user'
}

export default (state = initialState) => state
