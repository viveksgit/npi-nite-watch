import { combineReducers } from 'redux'
import meta from './meta'
import optionsChange from './optionsChange'
import sectionListing from './sectionListing'
import sectionQuestionListing from './sectionQuestionListing'
import categoryListing from './categoryListing'

export default combineReducers({
  meta,
  optionsChange,
  categoryListing,
  sectionListing,
  sectionQuestionListing
})
