import {FETCH_CATEGORIES, FETCH_CATEGORIES_COMPLETE, FETCH_CATEGORIES_ERROR} from '../actions/ActionTypes'

export default (state = {}, action) => {
  console.log('categoryListing reducer [action]', action)
  switch (action.type) {
    case FETCH_CATEGORIES:
      return Object.assign({}, {state: 'FETCHING'})
    case FETCH_CATEGORIES_COMPLETE:
      return Object.assign({}, {state: 'COMPLETE', result: action.result})
    case FETCH_CATEGORIES_ERROR:
      return Object.assign({}, {state: 'ERROR', result: action.result})
    default: return state
  }
}
