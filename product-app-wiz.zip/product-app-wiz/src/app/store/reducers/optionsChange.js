import {REFLEXIVE_OPTION_ANSWER_CHANGE, FETCH_SECTION_QUESTIONS} from '../actions/ActionTypes'

export default (state = {}, action) => {
  switch (action.type) {
    case REFLEXIVE_OPTION_ANSWER_CHANGE:
      return {...action}
    case FETCH_SECTION_QUESTIONS:
      return {}
    default: return state
  }
}
