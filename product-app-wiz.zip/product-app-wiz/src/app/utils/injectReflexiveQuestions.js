const cleanupQuestions = (questions, sectionQuestionRelId, newAnswer) => {
  const targetRemovals = {[sectionQuestionRelId]: sectionQuestionRelId}
  return questions.filter(question => {
    if (sectionQuestionRelId === question.sectionQuestionRelId) {
            // this questions answer has changed, so we need to refresh the answer
      question.recrusiveReflexiveCheck = false
      question.answer = newAnswer
    }

    if (!question.reflexiveFromSectionQuestionRelId) {
      return true
    }

    const removingQuestion = (
            question.reflexiveFromSectionQuestionRelId in targetRemovals
        )
    if (removingQuestion) {
      targetRemovals[question.sectionQuestionRelId] = question.sectionQuestionRelId
    }

    return !removingQuestion
  })
}

const weaveReflectiveQuestions = (questions, reflexiveQuestions, sectionQuestionRelId) => {
  console.log('weaveReflectiveQuestions [questions, reflexiveQuestions, sectionQuestionRelId]', questions, reflexiveQuestions, sectionQuestionRelId)
  questions.splice(
        questions.findIndex((question, index) => {
          return (question.sectionQuestionRelId === sectionQuestionRelId)
        }) + 1
        , 0
        , ...reflexiveQuestions
    )
  return questions
}

export const injectReflexiveQuestions = (currentSetOfQuestions, optionsChagneData) => {
  console.log('Section.injectReflexiveQuestions() currentSetOfQuestions ->', currentSetOfQuestions)
  console.log('Section.injectReflexiveQuestions() optionsChagneData ->', optionsChagneData)
  const cleanedUpQuestions = cleanupQuestions(currentSetOfQuestions, optionsChagneData.fullAnswer.sectionQuestionRelId, optionsChagneData.fullAnswer)
        // cleanup the questions in case the answer changed but has different questions to ask
  console.log('Section.loadReflexiveQuestions() cleanedUpQuestions ->', cleanedUpQuestions)
  if (optionsChagneData.reflexiveQuestions &&
        optionsChagneData.reflexiveQuestions.length > 0) {
    weaveReflectiveQuestions(cleanedUpQuestions, optionsChagneData.reflexiveQuestions, optionsChagneData.fullAnswer.sectionQuestionRelId)
  }
  console.log('Section.injectReflexiveQuestions() cleanedUpQuestions ->', cleanedUpQuestions)
  return cleanedUpQuestions
}
