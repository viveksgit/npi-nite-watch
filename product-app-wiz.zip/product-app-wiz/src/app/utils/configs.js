import isClient from './is-client'

export default isClient ? window.__CONFIG__ : {} // todo: add in require('config')
