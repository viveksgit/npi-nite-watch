import loadScript from './load-script'

export default callback => {
  const isGoodBrowser = 'fetch' in window && 'Promise' in window && 'assign' in Object
  if (isGoodBrowser) {
    callback()
  } else {
    loadScript('/product-app-wiz/assets/public/polyfills.min.js', callback)
  }
}
