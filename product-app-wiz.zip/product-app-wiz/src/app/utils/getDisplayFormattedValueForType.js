export default (s, value) => {
  switch (s) {
    case 'FORMAT_SSN':
      return value.replace(/(\d{3})(\d{2})(\d{4})/g, '$1-$2-$3')
    case 'FORMAT_PHONE':
      return value.replace(/(\d{3})(\d{3})(\d{4})/g, '($1) $2-$3')
    case 'FORMAT_NUMBER':
      if (value) {
        return (Number(value)).toLocaleString()
      } else {
        return value
      }
    default:
      return value
  }
}
