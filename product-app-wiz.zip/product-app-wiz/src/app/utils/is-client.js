export default typeof window !== "undefined" && window // eslint-disable-line
