export default (s, value) => {
  switch (s) {
    case 'WHOLE_NUMBER':
      return value.replace(/\D/g, '')
    case 'DECIMAL_NUMBER': // FIXME there is a bug here...12.12 does not work
      return value.replace(/\D/g, '')
    default:
      return value
  }
}
