export default (s) => {
  switch (s) {
    case 'VALIDATE_SSN':
      return /^\d{9}$/
    case 'VALIDATE_PHONE':
      return /^\d{10}$/
    case 'VALIDATE_NUMBER':
      return {
        test: (value, params) => {
          // console.log(`QuestionAnswerWrapper.save(): ${value} ${JSON.stringify(params)} ${Number(value)}`)
          if (value === undefined) {
            return false
          }
          const numberValue = Number(value)
          if (params.min !== undefined && numberValue < Number(params.min)) {
            return false
          }
          if (params.max && numberValue >= Number(params.max)) {
            return false
          }

          return true
        }
      }
    case 'BEFORETODAY':
      return {
        test: (value, params) => {
          const currentDate = new Date()
          currentDate.setHours(0, 0, 0, 0)
          const valueDate = new Date(value + 'T00:00:00')
          valueDate.setHours(0, 0, 0.0)
          return (valueDate < currentDate)
        }
      }
    case 'EMAIL':
      return /^(([^<>()\[\]\\.,;:\s@"']+(\.[^<>()\[\]\\.,;:\s@"']+)*)|(".+"'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    default:
      return {
        test: () => {
          // let it go
          return true
        }
      }
  }
}
