import React from 'react'
import { connect } from 'react-redux'

import Question from './question/Question'

// import {injectReflexiveQuestions} from '../utils/injectReflexiveQuestions'

import applicationQuestionsProxy from '../store/actions/ApplicationQuestionsProxy'

class SectionContainer extends React.Component {

    componentDidMount() {
        this.loadQuestions(this.props.productApplicationId, this.props.activeSectionId)
    }

    componentWillReceiveProps(nextProps) {
      console.log('SectionContainer.componentWillReceiveProps nextProps ->', nextProps)
      if (Number(nextProps.activeSectionId) !== Number(this.props.activeSectionId)) {
          this.loadQuestions(nextProps.productApplicationId, nextProps.activeSectionId)
      }
    }

    shouldComponentUpdate(nextProps, nextState) {
        // I noticed that this component was rendering twice with reflexive questions, which I traced to be an
        // issue with redux's dispatch.  The first invocation was the props were different, but the state was
        // equal, but the second invocation, the props were the same, but the state was different.
        // SO...since this component renders based on state, when the states were equal, we did not have to re-render
        // this component.

        // console.log('Section.shouldComponentUpdate() nextProps, nextState', nextProps, nextState);
        // console.log('SectionContainer.shouldComponentUpdate ->', this.props, nextProps, (this.props === nextProps))
        // console.log('STATE ->', this.state, nextState, (this.state === nextState))

        return this.props !== nextProps;

    }

    loadQuestions = (productAppId, sectionId) => {
        applicationQuestionsProxy.getQuestions(this.props.dispatch, productAppId, sectionId)
    }

    render() {
      console.log('SectionContainer.render props ->', this.props)
      if (!this.props.questions) {
          return (<span className="loading-indicator tiny" />)
      }

      const questionsForSection = this.props.questions.map(question => {
          return <Question
                  key={question.sectionQuestionRelId}
                  {...this.props}
                  config={question}
                  />
      })
      // questionsForSection.splice(7, 20)
      console.log('SectionContainer.render questionsForSection ->', questionsForSection)

      return (
          <div>
              {questionsForSection}
          </div>
      )
    }
}

const mapStateToProps = (reduxState) => {
  let questions = [];
  if (reduxState.sectionQuestionListing) {
    switch(reduxState.sectionQuestionListing.state) {
      case 'COMPLETE':
      case 'UPDATED':
        console.log('#########', reduxState.sectionQuestionListing.result)
        questions = reduxState.sectionQuestionListing.result
        break
      case 'ERROR':
        return { error: true, errorReason: reduxState.sectionQuestionListing.result }
        break
    }
  }

  return {
    questions
  }

}

export default connect(mapStateToProps)(SectionContainer)
