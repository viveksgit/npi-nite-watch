import React from 'react'

module.exports = ({text, subtext}) => (
  <div className='Banner'>
    <div className='grid-container'>
      <div className='row'>
        <div className='Banner-content columns small-12'>
          <span className='Banner-text'>{text}</span>
          <p>{subtext}</p>
        </div>
      </div>
    </div>
  </div>
)
