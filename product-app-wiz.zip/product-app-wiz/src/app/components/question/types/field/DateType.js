import React from 'react'
import PropTypes from 'prop-types'
require('date-format-lite')

const DateType = (props) => {
  const dateValue = (props.defaultValue !== undefined && props.defaultValue !== null) ? props.defaultValue.date('YYYY-MM-DD') : [new Date().getFullYear(), '01', '01'].join('-')
  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns'>
          <label id={`label-${props.config.questionName}-${props.config.sectionQuestionRelId}`} className='Question-text' htmlFor={props.config.questionText}>{props.config.questionText}</label>
          <input
            id={`${props.config.questionName}-${props.config.sectionQuestionRelId}`}
            name={`${props.config.questionName}`}
            type='date'
            onChange={props.change}
            onBlur={props.blur}
            value={dateValue}
          />
          <small className='error'>{(props.validationError) ? props.validationError : ''}</small>
        </div>
      </div>

    </div>
  )
}

DateType.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired
  }).isRequired,
  defaultValue: PropTypes.string,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired
}

export default DateType
