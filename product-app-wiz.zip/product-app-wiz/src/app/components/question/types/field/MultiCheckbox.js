import React from 'react'
import PropTypes from 'prop-types'
import camelCase from 'lodash/camelCase'
import DynamicOptionsWrapper from '../hoc/DynamicOptionsWrapper'

import Checkbox from './Checkbox'

const MultiCheckbox = (props) => {
  const selectedOptions = props.config && props.config.answer ? props.config.answer.code : props.defaultValue
  const options = (props.options)
    ? props.options.map((option, index) => {
      const isChecked = (props.defaultValue
        && props.defaultValue[option.optionName])
        ? props.defaultValue[option.optionName]
        : false
      return (
        <div className='Multi-option' key={index}>
          <Checkbox
            config={{
              questionName: option.optionName,
              questionText: option.text,
              sectionQuestionRelId: props.config.sectionQuestionRelId
            }}
            defaultValue={isChecked}
            change={event => props.singlePropertyChange(option.optionName, event.target.checked)} />
        </div>
      )
    })
    : (<option value='Loading...' key='loading'>Loading...</option>)

  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns'>
          <label
            id={`label-${camelCase(props.config.questionName)}-${props.config.sectionQuestionRelId}`}
            className='Question-text'>{props.config.questionText}</label>
          {options}
        </div>
      </div>
    </div>
  )
}

MultiCheckbox.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired,
    optionsURL: PropTypes.string,
    options: PropTypes.arrayOf(PropTypes.shape({
      code: PropTypes.number.isRequired,
      text: PropTypes.string.isRequired
    }))
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func
}

export default DynamicOptionsWrapper(MultiCheckbox)
