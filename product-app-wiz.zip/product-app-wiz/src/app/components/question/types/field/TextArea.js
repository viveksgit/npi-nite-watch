import React from 'react'
import PropTypes from 'prop-types'

const TextArea = (props) => {
  // console.log('Text.render() props -->', props)
  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns md-text-field with-floating-label'>
          <textarea
            id={`${props.config.questionName}-${props.config.sectionQuestionRelId}`}
            name={props.config.questionName}
            onChange={props.change}
            onBlur={props.blur}
            value={(props.defaultValue !== undefined && props.defaultValue !== null) ? props.defaultValue : ''}
            disabled={props.disabled}
            className={props.disabled ? 'has-focus' : ''}
          />
          <label
            id={`label-${props.config.questionName}-${props.config.sectionQuestionRelId}`}
            className='Question-text'
            htmlFor={`${props.config.questionName}-${props.config.sectionQuestionRelId}`}>{props.config.questionText}</label>
        </div>
      </div>
    </div>
  )
}

TextArea.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired,
  disabled: PropTypes.bool
}

export default TextArea
