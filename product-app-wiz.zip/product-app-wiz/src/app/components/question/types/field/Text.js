import React from 'react'
import PropTypes from 'prop-types'

import formatData from '../../../../utils/getDisplayFormattedValueForType'

const Text = (props) => {
    // console.log('Text.render() props -->', props)
  const cssClasses = [(props.disabled) ? 'has-focus' : '', (props.validationError) ? 'has-error' : '']
  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns md-text-field with-floating-label'>
          <input
            id={`${props.config.questionName}-${props.config.sectionQuestionRelId}`}
            name={props.config.questionName}
            type='text'
            onChange={props.change}
            onBlur={props.blur}
            value={(props.defaultValue !== undefined && props.defaultValue !== null) ? formatData(props.config.displayType, props.defaultValue) : ''}
            disabled={props.disabled}
            className={cssClasses.toString().replace(/\,/gi, ' ')}
            maxLength={props.maxLength}
          />
          <label
            id={`label-${props.config.questionName}-${props.config.sectionQuestionRelId}`}
            className='Question-text'
            htmlFor={`${props.config.questionName}-${props.config.sectionQuestionRelId}`}>{props.config.questionText}</label>
          <small className='error'>{(props.validationError) ? props.validationError : ''}</small>
        </div>
      </div>
    </div>
  )
}

Text.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired,
  disabled: PropTypes.bool,
  maxLength: PropTypes.number
}

export default Text
