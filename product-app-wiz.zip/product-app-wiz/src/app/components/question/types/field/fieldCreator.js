import React from 'react'

import Text from './Text'
import TextArea from './TextArea'
import Number from './Number'
import DateType from './DateType'
import Select from './Select'
import Radio from './Radio'
import Checkbox from './Checkbox'
import MultiCheckbox from './MultiCheckbox'

export default (type, config) => {
  switch (type) {
    case 'TEXT':
      return <Text {...config} />
    case 'TEXT_AREA':
      return <TextArea {...config} />
    case 'NUMBER':
      return <Number {...config} />
    case 'DATE':
      return <DateType {...config} />
    case 'DROPDOWN':
      return <Select {...config} />
    case 'RADIO':
      return <Radio
        {...config}
        change={(event, optionContext) => config.change(event, config.questionName, true, optionContext)} />
    case 'CHECKBOX':
      return <Checkbox
        {...config}
         />
        // TODO we should move the auto submit for change to be config based, not assume to be auto save
    case 'MULTISELECT_CHECKBOX':
      return <MultiCheckbox {...config} />
    default:
      return (
        <div>
          <h1>Should not see this: {type}</h1>
        </div>
      )
  }
}
