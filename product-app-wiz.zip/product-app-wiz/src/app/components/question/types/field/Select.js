import React from 'react'
import PropTypes from 'prop-types'
import camelCase from 'lodash/camelCase'
import DynamicOptionsWrapper from '../hoc/DynamicOptionsWrapper'

const Select = (props) => {
  let options
  if (props.options) {
    options = []
    options.push(<option key='selectme' disabled default> -- select an option -- </option>)
    options.push(...props.options.map(value => {
      return <option key={value.code} data-Type={value.type} value={value.code}>{value.text}</option>
    }))
  } else {
    options = (<option value='Loading...' key='loading'>Loading...</option>)
  }
  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns'>
          <div className='uitk-select md-text-field with-floating-label'>
            <select
              id={props.config.sectionQuestionRelId}
              name={props.config.questionName}
              value={(props.defaultValue !== undefined && props.defaultValue !== null) ? props.defaultValue : ''}
              className='os-default'
              onChange={event => props.change(event, {...props.options.find(option => option.code === event.target.value)}, true)}
              onBlur={props.blur}>
              {options}
            </select>
            <span className='select-arrow' />
            <label
              id={`label-${camelCase(props.config.questionName)}-${props.config.sectionQuestionRelId}`}
              className='Question-text'>{props.config.questionText}</label>
          </div>
        </div>
      </div>
    </div>
  )
}

Select.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired,
    optionsURL: PropTypes.string,
    options: PropTypes.arrayOf(PropTypes.shape({
      code: PropTypes.number.isRequired,
      text: PropTypes.string.isRequired
    }))
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired
}

export default DynamicOptionsWrapper(Select)
