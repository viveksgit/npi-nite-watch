import React from 'react'
import PropTypes from 'prop-types'
import camelCase from 'lodash/camelCase'

import DynamicOptionsWrapper from '../hoc/DynamicOptionsWrapper'

const Radio = (props) => {
  const options = (props.options)
        ? props.options.map(option => {
          const selectedOption =
                (props.config &&
                    props.config.answer &&
                    String(props.config.answer.code) === String(option.code)) ||
                (
                    String(props.defaultValue) == String(option.code)
                )
          const optionClassNames = props.options.length > 2 ? 'Multi-option md-multi-ctrl-field' : 'inline-block md-multi-ctrl-field'
          return (
            <div key={`${option.text}-${option.code}`} className={optionClassNames}>
              <input
                id={`${camelCase(option.text)}-${props.config.sectionQuestionRelId}`}
                name={props.config.questionName}
                type='radio'
                value={option.code}
                checked={selectedOption}
                onChange={event => { props.change(event, {type: option.type, text: option.text}) }}
              />
              <label
                id={`label-${camelCase(option.text)}-${props.config.sectionQuestionRelId}`}
                className='Option-width'
                htmlFor={`${camelCase(option.text)}-${props.config.sectionQuestionRelId}`}>{option.text}</label>
              {option.textSupplement && (
                <input
                  id={`${camelCase(option.text)}-${props.config.sectionQuestionRelId}-${option.code}-textSupplement`}
                  name={`${props.config.questionName}-textSupplement`}
                  type='text'
                  placeholder={option.textSupplementPlaceholder}
                  disabled={!selectedOption}
                  />
              )}
            </div>
          )
        })
        : (<option value='Loading...' >Loading...</option>)

  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns'>
          <label
            id={`label-${camelCase(props.config.questionName)}-${props.config.sectionQuestionRelId}`}
            className='Question-text'>{props.config.questionText}</label>
          {options}
        </div>
      </div>
    </div>
  )
}

Radio.propTypes = {
  config: PropTypes.shape({
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired,
    questionText: PropTypes.string.isRequired,
    optionsURL: PropTypes.string,
    options: PropTypes.arrayOf(PropTypes.shape({
      code: PropTypes.number.isRequired,
      text: PropTypes.string.isRequired
    }))
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired
}

export default DynamicOptionsWrapper(Radio)
