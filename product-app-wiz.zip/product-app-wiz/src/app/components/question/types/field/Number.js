import React from 'react'
import PropTypes from 'prop-types'

import Text from './Text'

import getDisplayFormattedValueForType from '../../../../utils/getDisplayFormattedValueForType'

const Number = (props) => {
  const numberVal = (props.defaultValue)
    ? props.defaultValue
    : ''
  const formattedNumber = (props.config.displayType)
    ? getDisplayFormattedValueForType(props.config.displayType, numberVal)
    : numberVal
  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns md-text-field with-floating-label'>
          <Text
            config={{
              questionText: props.config.questionText,
              sectionQuestionRelId: props.config.sectionQuestionRelId,
              questionName: props.config.questionName
            }}
            defaultValue={formattedNumber}
            change={props.change}
            blur={props.blur}
            validationError={props.validationError} />
        </div>
      </div>
    </div>
  )
}

Number.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired,
    displayType: PropTypes.string.isRequired
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired,
  disabled: PropTypes.bool
}

export default Number
