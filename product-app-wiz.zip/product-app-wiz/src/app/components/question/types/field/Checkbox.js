import React from 'react'
import PropTypes from 'prop-types'

const Checkbox = ({config, optionSelectionChange, defaultValue, change, blur}) => {
  return (
    <div className='inline md-multi-ctrl-field'>
      <input
        id={`${config.questionName}-${config.sectionQuestionRelId}`}
        name={config.questionName}
        type='checkbox'
        checked={(defaultValue === undefined || defaultValue === null) ? false : defaultValue}
        onChange={event => change(event, config.questionName, true)}
        onBlur={blur} />
      <label
        id={`label-${config.questionName}-${config.sectionQuestionRelId}`}
        htmlFor={`${config.questionName}-${config.sectionQuestionRelId}`}>{config.questionText}</label>
    </div>
  )
}

Checkbox.propTypes = {
  config: PropTypes.shape({
    questionText: PropTypes.string.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired,
    questionName: PropTypes.string.isRequired
  }).isRequired,
  change: PropTypes.func.isRequired,
  blur: PropTypes.func
}

export default Checkbox
