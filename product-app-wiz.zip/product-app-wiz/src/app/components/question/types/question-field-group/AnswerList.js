import React from 'react'
import PropTypes from 'prop-types'
import camelCase from 'lodash/camelCase'
import QuestionAnswerListWrapper from '../hoc/QuestionAnswerListWrapper'
import ListHeader from './ListHeader'
import ListItems from './ListItems'

const AnswerList = (props) => {
  // console.log(`AnswerList.render() -->`, props)

  return (
    <div className='grid-container'>
      <div className='row'>
        <div className='small-12 columns'>
          <table className='table' summary='This is a generic summmary that should be updated'>
            <ListHeader
              questionFields={props.config.questionFields} />
            <ListItems
              fields={props.config.questionFields}
              data={props.data.listItems}
              displayData={props.displayData}
              deleteEntry={props.deleteEntry}
              editEntry={props.editEntry} />
          </table>
        </div>
      </div>
    </div>
  )
}

AnswerList.propTypes = {
  data: PropTypes.shape({
    listItems: PropTypes.array.isRequired
  }),
  config: PropTypes.shape({
    questionFields: PropTypes.object.isRequired
  }),
  deleteEntry: PropTypes.func.isRequired,
  editEntry: PropTypes.func.isRequired
}

export default QuestionAnswerListWrapper(AnswerList)
