import React from 'react'
import PropTypes from 'prop-types'

import QuestionField from './QuestionField'

import applicationQuestionsProxy from '../../../../store/actions/ApplicationQuestionsProxy'

class AutoSaveQuestion extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      data: (props.config.answer) ? Object.assign({}, props.config.answer) : {}
    }
  }

  updateFormState = (field, updatedQuestionFieldData) => {
    console.log(`AutoSaveQuestion.updateFormState(${field} ${updatedQuestionFieldData})`)
    applicationQuestionsProxy.upsertAnswer(
      this.props.dispatch,
      this.props.productApplicationId,
      Object.assign(
        {},
        this.state.data,
        {[field]: updatedQuestionFieldData},
        {sectionQuestionRelId: this.props.config.sectionQuestionRelId}
      )
    )
  }

  shouldComponentUpdate(nextProps, nextState) {
    return (nextState.data !== this.state.data || nextState.data !== this.state.data)
  }

  componentWillReceiveProps(nextProps) {
    // console.log('QuestionAnswer.componentWillReceiveProps nextProps ->', nextProps)
    // console.log('QuestionAnswer.componentWillReceiveProps state ->', this.state)
    if (nextProps.config
      && nextProps.config.answer
      && nextProps.config.answer.id) {
      // since the updates are async, and coming from redux, they will come through the props
      // and we need to update our state to catch up with redux
      this.setState({data: nextProps.config.answer, validationErrors: nextProps.config.validationErrors})
    }
  }

  render() {
    console.log('AutoSaveQuestion.render()', this.state, this.props)
    const props = this.props
    // console.log(`ListItemForm.render()`, props)

    const questionFields = []
    for (let fieldKey of Object.keys(props.config.questionFields)) {
      // console.log(`ListItemForm.render() fieldKey ->`, fieldKey, props.config.questionFields[fieldKey])
      const fieldConfig = props.config.questionFields[fieldKey]
      if (fieldConfig.fieldText === 'CHANGE ME' && props.config.questionText !== '') {
        fieldConfig.fieldText = props.config.questionText
      }
      let data = (!this.state.data) ? '' : this.state.data[fieldKey]
      if (props.config.questionFields[fieldKey].fieldType === 'MULTISELECT_CHECKBOX') {
        data = this.state.data
      }

      questionFields.push((
        <QuestionField
          key={fieldKey}
          field={props.config.questionFields[fieldKey]}
          sectionQuestionRelId={props.config.sectionQuestionRelId}
          data={data}
          updateFormState={this.updateFormState}
          validationError={props.validationError}
        />
      ))
    }
    // console.log(`ListItemForm.render questionFields`, questionFields)

    return (
      <div className='grid-container'>
        <div className='row'>
          <div className='small-12 columns'>
            {questionFields}
          </div>
        </div>
      </div>
    )
  }
}

AutoSaveQuestion.propTypes = {
  data: PropTypes.object,
  // persistEntry: PropTypes.func.isRequired,
  config: PropTypes.shape({
    questionFields: PropTypes.object.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired
  }).isRequired,
  // editIndex: PropTypes.number,
  validationError: PropTypes.string
  // cancelEntryEdit: PropTypes.func.isRequired
}

export default AutoSaveQuestion
