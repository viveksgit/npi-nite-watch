import React from 'react'
import PropTypes from 'prop-types'

const ListHeader = (props) => {
  // console.log('DataListHeader.render()', props, Object.keys(props.questionFields))
  const headerColumns = []
  for (let fieldKey of Object.keys(props.questionFields)) {
    headerColumns.push((
      <th key={fieldKey}>{props.questionFields[fieldKey].fieldText}</th>
    ))
  }
  headerColumns.push(<th key='delete'>Delete</th>)
  headerColumns.push(<th key='edit'>Edit</th>)
  return (
    <thead>
      <tr>
        {headerColumns}
      </tr>
    </thead>
  )
}

ListHeader.propTypes = {
  questionFields: PropTypes.object.isRequired
}

export default ListHeader
