import React from 'react'
import PropTypes from 'prop-types'

import fieldCreator from '../field/fieldCreator'
import FieldAnswerWrapper from '../hoc/FieldAnswerWrapper'

const QuestionField = (props) => {
  const fieldConfig = {
    config: {
      questionText: props.field.fieldText,
      sectionQuestionRelId: props.sectionQuestionRelId,
      questionName: props.field.name,
      optionsURI: props.field.optionsURI,
      displayType: props.field.displayType
    },
    defaultValue: props.data,
    change: props.change,
    singlePropertyChange: props.singlePropertyChange,
    blur: props.blur,
    validationError: props.validationError
  }

  return fieldCreator(props.field.fieldType, fieldConfig)
}

QuestionField.propTypes = {
  field: PropTypes.shape({
    fieldText: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    dataType: PropTypes.string.isRequired,
    displayType: PropTypes.string.isRequired
  }).isRequired,
  sectionQuestionRelId: PropTypes.number.isRequired,
  defaultValue: PropTypes.string,
  change: PropTypes.func.isRequired,
  singlePropertyChange: PropTypes.func.isRequired,
  blur: PropTypes.func.isRequired,
  validationError: PropTypes.string
}

export default FieldAnswerWrapper(QuestionField)
