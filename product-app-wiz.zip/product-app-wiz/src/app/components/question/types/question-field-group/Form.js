import React from 'react'
import PropTypes from 'prop-types'

import QuestionField from './QuestionField'

class Form extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      data: (this.props.data) ? Object.assign({}, this.props.data) : {}
    }
  }

  updateFormState = (field, updatedQuestionFieldData) => {
    // console.log(`Form.updateFormState(${field} ${updatedQuestionFieldData})`)
    const willBeNewState = this.state.data
    willBeNewState[field] = updatedQuestionFieldData
    this.setState({data: willBeNewState})
  }

  persistMyState = () => {
    // console.log('Persisting my state!!!')
    this.props.persistEntry(this.state.data, this.props.editIndex)
  }

  render() {
    const props = this.props
    // console.log(`ListItemForm.render()`, props)

    const questionFields = []
    for (let fieldKey of Object.keys(props.config.questionFields)) {
      // console.log(`ListItemForm.render() fieldKey ->`, fieldKey, props.config.questionFields[fieldKey])
      questionFields.push((
        <QuestionField
          key={fieldKey}
          field={props.config.questionFields[fieldKey]}
          sectionQuestionRelId={props.config.sectionQuestionRelId}
          data={(!this.state.data) ? '' : this.state.data[fieldKey]}
          updateFormState={this.updateFormState}
          validationError={props.validationError}
        />
      ))
    }
    // console.log(`ListItemForm.render questionFields`, questionFields)

    return (
      <div className='grid-container'>
        <div className='row'>
          <div className='small-12 columns'>
            {questionFields}
          </div>
        </div>
        <div className='row'>
          <div className='small-12 columns'>
            <button className='button btn-cta tiny' onClick={this.persistMyState}>{(this.props.editIndex === -1) ? 'Add' : 'Save'}</button>
            <button className='button btn-cta tertiary tiny' onClick={this.props.cancelEntryEdit}>Cancel</button>
          </div>
        </div>
      </div>
    )
  }
}

Form.propTypes = {
  data: PropTypes.object,
  persistEntry: PropTypes.func.isRequired,
  config: PropTypes.shape({
    questionFields: PropTypes.object.isRequired,
    sectionQuestionRelId: PropTypes.number.isRequired
  }).isRequired,
  editIndex: PropTypes.number,
  validationError: PropTypes.string,
  cancelEntryEdit: PropTypes.func.isRequired
}

export default Form
