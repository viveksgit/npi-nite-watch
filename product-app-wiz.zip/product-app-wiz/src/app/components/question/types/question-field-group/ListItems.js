import React from 'react'
import PropTypes from 'prop-types'

const ListItems = (props) => {
  let rows = []

  if (!props.data || props.data.length === 0) {
    rows.push(<tr key='empty'><td colSpan={Object.keys(props.fields).length + 2}><div data-notification='' className='notification-box info'> There are no items to display </div></td></tr>)
  } else {
    rows = props.data.map((dataRow, rowIndex) => {
      const data = []
      for (let fieldKey of Object.keys(props.fields)) {
        data.push((
          <td key={`${rowIndex} + '-' + ${fieldKey}`}>
            {(props.displayData && props.displayData[rowIndex])
              ? props.displayData[rowIndex][fieldKey]
              : dataRow[fieldKey]}
          </td>
        ))
      }
      data.push(<td key={`${rowIndex}-delete`}><button className='button btn-cta alert tiny valign-middle margin-bottom-none' onClick={() => props.deleteEntry(rowIndex)}>Delete</button></td>)
      data.push(<td key={`${rowIndex}-edit`}><button className='button btn-cta warning tiny valign-middle margin-bottom-none' onClick={() => props.editEntry(rowIndex)}>Edit</button></td>)
      return (
        <tr key={rowIndex}>
          {data}
        </tr>
      )
    })
  }

  return (
    <tbody>
      {rows}
    </tbody>
  )
}

ListItems.propTypes = {
  data: PropTypes.array.isRequired,
  fields: PropTypes.object.isRequired,
  deleteEntry: PropTypes.func.isRequired,
  editEntry: PropTypes.func.isRequired
}

export default ListItems
