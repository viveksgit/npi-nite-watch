import React from 'react'

import valsProxy from '../../../../store/actions/ValsProxy'

function DynamicOptionsWrapper (WrappedComponent) {
  class DynamicOptions extends React.Component {
    constructor (props) {
      super(props)
      let selectedOption = (props.defaultValue) ? { code: Number(props.defaultValue) } : { code: -1 }
      if (typeof props.defaultValue === 'object') {
        selectedOption = props.defaultValue
      }
      this.state = {
        options: props.config.options,
        selectedOption: selectedOption
      }
    }

    componentDidMount () {
      // console.log('DynamicOptions.componentDidMount() props ->', this.props)
      if (!this.state.options && this.props.config.optionsURI) {
        valsProxy.getOptions(this.props.config.optionsURI)
                .then(selectOptions => {
                  // console.log('DynamicOptions.componentDidMount() selectOptions ->', selectOptions)
                  this.setState({options: selectOptions})
                })
      }
    }

    componentWillReceiveProps (nextProps) {
      // console.log('DynamicOptions.componentWillReceiveProps() nextProps ->', nextProps)
      if (nextProps.defaultValue !== this.state.selectedOption.code) {
        // console.log('We need to update the state!')
        this.setState({ selectedOption: { code: nextProps.defaultValue } })
      }
    }

    render () {
      return (
        <WrappedComponent
          options={this.state.options}
          selectedOption={this.state.selectedOption}
          {...this.props} />
      )
    }
  }

  return DynamicOptions
}

export default DynamicOptionsWrapper
