import React from 'react'
import PropTypes from 'prop-types'

import camelCase from 'lodash/camelCase'

import Form from '../question-field-group/Form'

import applicationQuestionsProxy from '../../../../store/actions/ApplicationQuestionsProxy'
import valsProxy from '../../../../store/actions/ValsProxy'

import getDisplayFormattedValueForType from '../../../../utils/getDisplayFormattedValueForType'

function QuestionAnswerListWrapper(WrappedComponent, initializedStateData) {

    class QuestionAnswerList extends React.Component {

        constructor(props) {
            super(props);
            // console.log('QuestionAnswerList.constructor() props ->', props)

            const answerData = (props.config.answer && props.config.answer.listItems && Array.isArray(props.config.answer.listItems)) 
              ? props.config.answer
              : {listItems: [], sectionQuestionRelId: props.config.sectionQuestionRelId}

            this.state = {
                initializing: true,
                data: answerData
                , createNewItem: false
                , editEntryIndex: -1
            }
        }

        save = (dataToPersist = this.state.data) => {
          // console.log('QuestionAnswerWrapper.blur() posting update for state ->', dataToPersist)
          dataToPersist.sectionQuestionRelId =
          applicationQuestionsProxy.upsertAnswer(this.props.dispatch, this.props.productApplicationId, Object.assign({}, dataToPersist, {sectionQuestionRelId: this.props.config.sectionQuestionRelId}))
          // this.setState({data: {...dataToPersist}, createNewItem: false, editEntryIndex: -1, displayData})
          this.syncStateData(dataToPersist)
        }

        startCreateNewItem = (e) => {
          // console.log(`QeustionAnswerListWrapper.addNewItem()!`)
          this.setState({createNewItem: true})
        }

        cancelEntryEdit = () => {
          this.setState({createNewItem: false, editEntryIndex: -1})
        }

        editEntry = (index) => {
          // console.log(`QeustionAnswerListWrapper.editEntry(${index})!`)
          this.setState({editEntryIndex: index})
        }

        persistEntry = (item, index) => {
          // console.log(`QuestionAnswerList.persistEntry(${item}, ${index})`)
          const willBeNewState = this.state.data
          if (index >= 0) {
            willBeNewState.listItems[index] = item
          } else {
            willBeNewState.listItems.push(item)
          }
          this.save(willBeNewState)
        }

        deleteEntry = (index) => {
          // console.log('About to delete entry', index)
          const willBeNewState = this.state.data
          willBeNewState.listItems.splice(index, 1)
          this.save(willBeNewState)
        }

        syncStateData = (data = this.state.data, questionFields = this.props.config.questionFields) => {
          const displayDataPromises = []
          const displayDataItems = data.listItems.forEach((item, index) => {
            for (let field of Object.keys(questionFields)) {
              if (questionFields[field].optionsURI !== '') {
                displayDataPromises.push(
                  valsProxy.getOptions(questionFields[field].optionsURI)
                    .then(selectOptions => {
                      // console.log(selectOptions)
                      const option = selectOptions.find(option => option.code === item[field])
                      if (option) {
                        return {index, field, val: option.text}
                      } else {
                        return {index, field, val: item[field]}
                      }
                    })
                )
              } else {
                const formattedValue = getDisplayFormattedValueForType(questionFields[field].displayType, item[field])
                displayDataPromises.push(Promise.resolve({index, field, val: formattedValue}))
              }
            }
          })
          Promise.all(displayDataPromises)
            .then(allPromises => {
              const displayData = allPromises.reduce((rows, fieldPromise) => {
                if (!rows[fieldPromise.index]) {
                  rows[fieldPromise.index] = {}
                }
                rows[fieldPromise.index][fieldPromise.field] = fieldPromise.val
                return rows
              }, [])
              // console.log('QuestionAnswerList.componentWillReceiveProps displayData ->', displayData)
              this.setState({data, displayData, initializing: false, createNewItem: false, editEntryIndex: -1})
            })
        }

        componentWillReceiveProps(nextProps) {
          if (nextProps.config.answer && nextProps.config.answer.listItems.length) {
            // lets hijack the state and inject some display values
            this.syncStateData(nextProps.config.answer, nextProps.config.questionFields)
          }
        }

        componentDidMount = () => {
          this.syncStateData()
        }

        render() {
          console.log(`QuestionAnswerList.render()`)
          if (this.state.initializing) {
            return (
              <div><span className="loading-indicator tiny"></span></div>
            )
          }
          return (
            <div className='grid-container'>
              <div className='row'>
                <div className='small-12 columns'>
                  <span id={`label-${camelCase(this.props.config.questionName)}-${this.props.config.sectionQuestionRelId}`} className='Question-text'>{this.props.config.questionText}</span>
                </div>
              </div>
              {(this.state.data.listItems.length !== 0) &&
                <div>
                  <div className='row'>
                    <div className='small-12 columns'>
                      <WrappedComponent
                        {...this.props}
                        data={this.state.data}
                        displayData={this.state.displayData}
                        deleteEntry={this.deleteEntry}
                        editEntry={this.editEntry}
                      />
                    </div>
                  </div>
                  <div className='row'>
                    <div className='small-12 columns'>
                      <button className={`button btn-cta tiny ${(this.state.createNewItem) ? 'disabled' : ''}`} onClick={this.startCreateNewItem}>Create New Entry</button>
                    </div>
                  </div>
                </div>
              }
              {(this.state.createNewItem || this.state.editEntryIndex > -1 || this.state.data.listItems.length === 0) &&
                <div className='row'>
                  <div className='small-12 columns'>
                    <Form
                      config={this.props.config}
                      persistEntry={this.persistEntry}
                      data={(this.state.editEntryIndex < 0) ? {} : this.state.data.listItems[this.state.editEntryIndex]}
                      editIndex={this.state.editEntryIndex}
                      cancelEntryEdit={this.cancelEntryEdit}
                      />
                  </div>
                </div>
              }
            </div>
          )
        }

    }

    QuestionAnswerList.propTypes = {
        productApplicationId: PropTypes.number.isRequired,
        config: PropTypes.shape({
          answer: PropTypes.object,
          sectionQuestionRelId: PropTypes.number
        }),
        dispatch: PropTypes.func.isRequired,
        productApplicationId: PropTypes.number.isRequired
    }

    return QuestionAnswerList

}

export default QuestionAnswerListWrapper
