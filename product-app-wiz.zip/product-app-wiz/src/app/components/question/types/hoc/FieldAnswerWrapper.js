import React from 'react'
import PropTypes from 'prop-types'
import concat from 'lodash/concat'

import getPersistedValueForType from '../../../../utils/getPersistedValueForType'
import getValidatorImplForType from '../../../../utils/getValidatorImplForType'

import Question from '../../Question'

function FieldAnswerWrapper(WrappedComponent, initializedStateData) {

  class FieldAnswer extends React.Component {

    constructor(props) {
      super(props);

      this.state = {
        data: props.data,
        changed: false,
        validationErrors: null
      }
    }

    singlePropertyChange = (property, value) => {
      this.props.updateFormState(property, value)
      const newDataState = Object.assign({}, this.state.data, {[property]: value})
      this.updateMyStateData(newDataState)
    }

    change = (event, overrideFieldName, forceSave, optionContext) => {
      console.log('QuestionAnswer.change() ->', event, overrideFieldName, forceSave, optionContext)
      const target = event.target;
      const value = target.type === 'checkbox' ? target.checked : target.value;
      const field = (overrideFieldName) ? overrideFieldName : target.name;
      const persistedValue = getPersistedValueForType(this.props.field.dataType, value)
      console.log('QuestionAnswer.change() persistedValue ->', persistedValue)
      if (forceSave) {
        this.save(persistedValue)
      } else {
        this.setState({data: persistedValue, changed: true})
      }
    }

    save = (dataToPersist = this.state.data) => {
      // console.log(`FieldAnswer.save() dataToPersist ->`, dataToPersist)
      if (this.props.field
          && this.props.field.fieldValidations
          && this.props.field.fieldValidations.length) {
        const validationErrors = this.props.field.fieldValidations.reduce((accum, validationConfig) => {
          const extractedValue = getPersistedValueForType(this.props.field.dataType, dataToPersist)
          const passedValidation = getValidatorImplForType(validationConfig.validateType).test(extractedValue, validationConfig.validateParams)
          if (!passedValidation) {
            accum[validationConfig.field] = validationConfig.errorMessage
          }
          return accum
        }, {})

        if (Object.keys(validationErrors).length) {
          this.setState({validationErrors})
          return // done with this function, and continue on
        }
      }
      // only here if there are no validation errors
      this.props.updateFormState(this.props.field.name, dataToPersist)
      this.updateMyStateData(dataToPersist)
    }

    updateMyStateData = (data) => {
      this.setState({data, changed: false, validationErrors: null})
    }

    blur = (event) => {
      if (this.state.changed) {
        this.save()
      }
    }

    render() {

      return (
        <WrappedComponent
          {...this.props}
          data={this.state.data}
          change={this.change}
          singlePropertyChange={this.singlePropertyChange}
          blur={this.blur}
          validationError={(this.state.validationErrors) ? this.state.validationErrors[this.props.field.name]: null}
          />
      )
    }

  }

  FieldAnswer.propTypes = {
    field: PropTypes.shape({
      fieldValidations: PropTypes.array,
      dataType: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired
    }).isRequired,
    updateFormState: PropTypes.func.isRequired
  }

  return FieldAnswer

}

export default FieldAnswerWrapper
