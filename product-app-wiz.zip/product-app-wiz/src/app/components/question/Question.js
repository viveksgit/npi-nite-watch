import React from 'react'

import AnswerList from './types/question-field-group/AnswerList'
import AutoSaveQuestion from './types/question-field-group/AutoSaveQuestion'

const Question = (props) => {
  let question = null

  if (props.config.listAnswer) {
    question = (
      <AnswerList
        config={props.config}
        productApplicationId={props.productApplicationId}
        dispatch={props.dispatch} />
      )
  } else {
    question = (
      <AutoSaveQuestion
        config={props.config}
        productApplicationId={props.productApplicationId}
        dispatch={props.dispatch}  />
      )
  }

  return (
    <div className='card margin-top-large margin-right-large'>
      <div id={`${props.config.questionGroupType}-${props.config.sectionQuestionRelId}`}>
        {question}
      </div>
    </div>
  )
}

export default Question
