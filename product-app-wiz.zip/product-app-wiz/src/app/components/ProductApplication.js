import React from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import findIndex from 'lodash/findIndex'
import Header from './Header'
import SectionListing from './SectionCategoryListing'
import SectionContainer from './SectionContainer'
import applicationQuestionsProxy from '../store/actions/ApplicationQuestionsProxy'
import printProxy from '../store/actions/printProxy.js'

class ProductApplication extends React.Component {
  constructor () {
    super()
    this.state = {
      'isLoading': false,
      'isError': false,
      'tabPref': null
    }
    this.onPrint = this.onPrint.bind(this)
  }
  componentDidMount () {
    applicationQuestionsProxy.getRequiredSections(this.props.dispatch, this.props.productApplicationId)
  }
  shouldComponentUpdate (nextProps, nextState) {
    return this.props !== nextProps || this.state !== nextState
  }
  componentDidUpdate () {
    if (this.state.isLoading) {
      printProxy.getPdf(this.props.productApplicationId)
        .then((response) => {
          this.setState({isLoading: false})
          if (response.data.url) {
            this.setState({isError: false})
            switch (this.state.tabPref) {
              case 'new_tab':
                return window.open(`${response.data.url}`)
              case 'current_tab':
                return window.location.assign(`${response.data.url}`)
              default :
                return window.open(`${response.data.url}`)
            }
          } else {
            this.setState({isError: true})
          }
        })
    }
  }
  onPrint (tabPref) {
    this.setState({ isLoading: true, tabPref: tabPref })
    return true
  }
  render () {
    let nextSectionId = null
    let prevSectionId = null
    if (this.props.productAppSections) {
      const activeSectionIndex = findIndex(this.props.productAppSections, (section) => {
        return Number(section.sectionId) === Number(this.props.activeSectionId)
      })
      const nextSection = this.props.productAppSections[activeSectionIndex + 1]
      const prevSection = this.props.productAppSections[activeSectionIndex - 1]
      nextSectionId = nextSection ? nextSection.sectionId : -1
      prevSectionId = prevSection ? prevSection.sectionId : -1
    }
    return (
      <div>
        <Header username={this.props.userName} onPrint={(tabPref) => this.onPrint(tabPref)} />
        {this.state.isLoading ? <div className='grid-container'>
          <div className='reveal-overlay show'>
            {this.state.isError ? <div className='reveal show'><div className='reveal-content'><p>{'Unable to print at this time. Please try again later'}</p></div></div> : <span className='loading-indicator Loader' />}
          </div>
        </div> : null}
        <div className='grid-container'>
          <div className='row'>
            <div className='small-2 medium-3 columns'>
              <SectionListing
                activeSectionId={this.props.activeSectionId}
                productApplicationId={this.props.productApplicationId}
              />
            </div>
            <div className='small-10 medium-9 columns'>
              <SectionContainer
                activeSectionId={this.props.activeSectionId}
                productApplicationId={this.props.productApplicationId} />
              {this.props.loadedSectionListings
              ? <div className='margin-top-large margin-right-large'>
                <Link to={`../section/${prevSectionId}`}>
                  <button className='button btn-cta tertiary'><span className='icon icon-util-left-alt' />prev</button>
                </Link>
                <Link to={`../section/${nextSectionId}`} className='right'>
                  <button className='button btn-cta tertiary'>next<span className='icon icon-util-right-alt' /></button>
                </Link>
              </div>
                : <div>
                  <span className='loading-indicator tiny' />
                </div>
            }
            </div>
          </div>
        </div>
      </div>
    )
  }
}

const mapReduxStateToProps = (reduxState) => {
  const userName = reduxState.meta.userName
  if (reduxState.sectionListing) {
    switch (reduxState.sectionListing.state) {
      case 'COMPLETE':
        return {
          productAppSections: reduxState.sectionListing.result,
          loadedSectionListings: true,
          userName: userName
        }
      case 'ERROR':
        return {
          error: reduxState.sectionListing.result,
          loadedSectionListings: true,
          userName: userName
        }
      case 'FETCHING':
        return {
          loadedSectionListings: false,
          userName: userName
        }
    }
  }
  return {}
}

export default connect(mapReduxStateToProps)(ProductApplication)
