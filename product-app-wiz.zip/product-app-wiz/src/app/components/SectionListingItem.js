import React from 'react'
import { Link } from 'react-router-dom'

const SectionListingItem = ({activeSectionId, section}) => {
    // console.log('Section.render() -->', activeSection, section);
  const cssClass = (Number(activeSectionId) === section.sectionId)
        ? 'tab-title active'
        : 'tab-title'
  return (
    <li key={section.id} className={cssClass}>
      <Link to={`../section/${section.sectionId}`} id={`section-${section.sectionId}`}>{section.sectionName}</Link>
    </li>
  )
}

export default SectionListingItem
