import React from 'react'
import { connect } from 'react-redux'

import SectionListingItem from './SectionListingItem'

import applicationQuestionsProxy from '../store/actions/ApplicationQuestionsProxy'

class SectionCategoryListing extends React.Component {
  componentDidMount () {
    applicationQuestionsProxy.getRequiredCategories(this.props.dispatch, this.props.productApplicationId)
  }

  render () {
    // console.log('SectionListing.render() props ->', this.props)
    if (!this.props.loadedCategoryListings) {
      return (
        <div>
          <span className='loading-indicator tiny' />
        </div>
      )
    }

    const categories = this.props.productAppCategories.map(category => {
      return (
        <li key={category.sectionCategoryId} className='tab-title'>
          <span>{category.sectionCategoryName}</span>
          <ul className='tabs vertical'>
            {category.sections.map(section => {
              return <SectionListingItem
                key={section.sectionId}
                activeSectionId={this.props.activeSectionId}
                section={section} />
            })}
          </ul>
        </li>
      )
    })

    return (
      <div className='card margin-top-large'>
        <ul className='tabs vertical'>
          {categories}
        </ul>
      </div>
    )
  }
}

const mapReduxStateToProps = (reduxState) => {
  // console.log('SectionListing.mapStateToProps ->', reduxState)
  if (reduxState.categoryListing) {
    switch (reduxState.categoryListing.state) {
      case 'COMPLETE':
        return {
          productAppCategories: reduxState.categoryListing.result,
          loadedCategoryListings: true
        }
      case 'ERROR':
        return {
          error: reduxState.categoryListing.result,
          loadedCategoryListings: true
        }
      case 'FETCHING':
        return {
          loadedCategoryListings: false
        }
    }
  }
  return {}
}

export default connect(mapReduxStateToProps)(SectionCategoryListing)
