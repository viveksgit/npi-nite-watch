import React from 'react'
import createStore from './store/createStore'
import { fetchInitialState } from './store/actions/ActionCreators'
import makeFetch from './utils/make-fetch'
import { Provider } from 'react-redux'

import ProductApplication from './components/ProductApplication'

const store = createStore({}, makeFetch)
store.dispatch(fetchInitialState())

const Entry = (props) => {
  console.log('Entry.render ->', props)
  return (
    <Provider store={store}>
      <ProductApplication
        productApplicationId={Number(props.productApplicationId)}
        activeSectionId={props.activeSectionId} />
    </Provider>
  )
}

export default Entry
