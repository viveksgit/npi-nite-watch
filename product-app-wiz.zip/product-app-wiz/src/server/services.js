import { get, put } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, normalizeJson, logSuccess } from './utils'

export const getExample = (headers, logger) =>
  get(`${domains.nmlvhub}${services.example}/`, { headers })
    .then(checkHttpStatus)
    .then(normalizeJson)
    .then(logSuccess(logger, { message: 'get example success' }))

export const putExample = (headers, body, logger) =>
  put(`${domains.nmlvhub}${services.example}`, body, { headers })
    .then(checkHttpStatus)
    .then(normalizeJson)
    .then(logSuccess(logger, { message: 'post example success' }))
