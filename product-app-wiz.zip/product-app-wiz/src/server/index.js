require('source-map-support').install()

import 'newrelic'
import 'isomorphic-fetch' // global pollyfills
import https from 'https'
import http from 'http'
import certs from 'nmlvhub-node-certs-lastmile'
import log from 'nmlvhub-node-logger'
import { util } from 'config'
import app from './app'

const httpListenerPort = (() => {
  if (process.env.KUBERNETES_SERVICE_HOST) {
    return 80
  }
  return 8080
})()

const httpsListenerPort = (() => {
  if (process.env.KUBERNETES_SERVICE_HOST) {
    return 443
  }
  return 8443
})()

log.info(`NODE_ENV: ${util.getEnv('NODE_ENV')}`)
log.info(`NODE_APP_INSTANCE: ${util.getEnv('NODE_APP_INSTANCE')}`)
log.info(`NODE_CONFIG_DIR: ${util.getEnv('NODE_CONFIG_DIR')}`)
log.levels(
  0,
  process.env.BUNYAN_LOG_LEVEL ? parseInt(process.env.BUNYAN_LOG_LEVEL, 10) : 30 /* INFO */
)
log.info(`log.levels(): ${log.levels()}`)

const httpServer = http.createServer(app).listen(httpListenerPort, () => {
  log.info(`app is listening at localhost: ${httpListenerPort}`)
})

if (!process.env.KUBERNETES_SERVICE_HOST) {
  // Override default ports when running on windows or mac
  // turn HTTPS cert reject off to ensure that certs don't fail in chrome
  certs.apiCerts.rejectUnauthorized = false
}

const httpsServer = https.createServer(certs.apiCerts, app).listen(httpsListenerPort, () => {
  log.info(`app is listening at localhost:: ${httpsListenerPort}`)
})

process.on('SIGTERM', () => {
  httpServer.close(() => {
    log.info('SIGTERM issued...app is shutting down')
    process.exit(0)
  })

  httpsServer.close(() => {
    log.info('SIGTERM issued...app is shutting down')
    process.exit(0)
  })
})
