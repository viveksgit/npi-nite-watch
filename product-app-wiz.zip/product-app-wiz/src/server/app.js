import 'newrelic'
import express from 'express'
import attachRunMiddleware from 'run-middleware'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
import { basePath, assetPath, domains, cookieNames } from 'config'
import csrf from 'csurf'
import url from 'url'

import { isDev, axiosInterceptors } from './utils'
import { validateHealth, validateRoot, validateUserInfo } from './validation'
import {
    getHealth,
    getApp,
    getCategories,
    getSections,
    getQuestions,
    getReflexiveQuestions,
    getListOfValues,
    getPdf,
    getNBListOfValues,
    upsertAnswers } from './routes'
import {
  errorCacheAll,
  errorNotFound,
  errorValidation,
  cacheControl,
  newrelic,
  logger,
  loggedInUserInfoInjector
} from './middleware'

const app = express()
const api = express.Router()
const domain = url.parse(domains.srcdq).hostname

const csrfProtection = csrf({
  cookie: { secure: !isDev, httpOnly: true, domain }
})
app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true
  })
)

attachRunMiddleware(app)

app.disable('x-powered-by')
app.use(logger())
app.use(loggedInUserInfoInjector())
app.use(newrelic())
app.use(cacheControl())
api.use(cookieParser())

// TODO: set in nginx?
if (process.env.NODE_ENV === 'development') {
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header(
      'Access-Control-Allow-Headers',
      'Origin, X-Requested-With, Content-Type, Accept, Credentials'
    )
    next()
  })
}
app.use(`${basePath}${assetPath}`, express.static('build/public', { maxAge: '365d' }))

// ENDPOINTS
api.route('/').get(validateRoot, csrfProtection, getApp)
api.route('/:productApplicationId/section/:sectionId').get(validateRoot, csrfProtection, getApp)

api.route('/api/productApp/:productApplicationId/categories').get(csrfProtection, validateRoot, validateUserInfo, getCategories)
api.route('/api/productApp/:productApplicationId/sections').get(csrfProtection, validateRoot, validateUserInfo, getSections)
api.route('/api/productApp/:productApplicationId/sections/:sectionId').get(csrfProtection, validateRoot, validateUserInfo, getQuestions)
api.route('/api/productApp/:productApplicationId/answers').put(validateRoot, validateUserInfo, upsertAnswers)
api.route('/api/reflexiveQuestions/:productApplicationId').get(csrfProtection, validateRoot, validateUserInfo, getReflexiveQuestions)
api.route('/api/listOfValues/:listOfValueName').get(csrfProtection, validateRoot, getListOfValues)
api.route('/api/newbusiness/listOfValues/:listOfValueName').get(csrfProtection, validateRoot, getNBListOfValues)
api.route('/api/pdfGeneration/:productAppId').get(csrfProtection, validateRoot, getPdf)

api.route('/health').get(validateHealth, getHealth)

app.use(basePath, api)

// ERROR HANDLING
app.use(errorValidation())
app.use(errorNotFound())
app.use(errorCacheAll())

export default app
