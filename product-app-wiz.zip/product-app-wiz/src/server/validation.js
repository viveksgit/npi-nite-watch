import * as Joi from 'joi'
import jwtDecoder from 'jwt-decode'
import { getUserInfo } from './services/getUserInfo'

const headers = Joi.object().keys().unknown()

export const validateRoot = (req, res, next) => {
  Joi.validate(req.headers, headers, err => {
    if (err) {
      return next(err)
    }
    return next()
  })
}

export const validateUserInfo = (req, res, next) => {
  if (!req.headers['x-nm-app-user-info']) {
    return next('User identity IS required')
  } else {
    return next()
  }
}

export const validateHealth = (req, res, next) => {
  Joi.validate(req.headers, headers, err => {
    if (err) {
      return next(err)
    }
    return next()
  })
}
