import axios from 'axios'

console.log('axios interceptors are getting configured!!')
axios.interceptors.request.use(config => {
  config.requestTime = Date.now()
  return config
})

axios.interceptors.response.use(response => {
  if (response.config.logger && response.config.requestTime) {
    response.config.logger.info({ serviceResponseTime: Date.now() - response.config.requestTime })
  }
  return response
})
