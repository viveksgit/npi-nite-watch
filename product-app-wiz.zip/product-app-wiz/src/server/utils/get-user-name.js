export default req => req.headers['x-nm-app-user-info'] ? req.headers['x-nm-app-user-info'].fullName : 'no_user'
