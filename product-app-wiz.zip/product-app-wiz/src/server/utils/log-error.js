export default (log, message, throwError = true, defaultReturn = null) => error => {
  log.error(Object.assign({ message }, { error: error.message, msg: error.response }))
  if (throwError) {
    throw error
  }
  return defaultReturn
}
