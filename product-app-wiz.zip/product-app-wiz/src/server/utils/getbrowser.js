import useragent from 'useragent'
export const getBrowser = req => useragent.is(req.headers['user-agent'])
