import {getFinancialRepData} from '../services/getFinancialRepData'

export default (headers, logger, question) => {
  switch (question.questionGroupType) {
    case 'FINANCIAL_REP':
      if (question.answer && question.answer.frData) {
        return Promise.resolve(getFinancialRepData(headers, logger, question.answer.frData.nmUniqueId))
        .then(frDetails => {
          const fr = Object.assign({}, question.answer, {supplementalDetails: frDetails})
          return Object.assign({}, question, {answer: {id: question.answerId, fr}})
        })
      } else {
        return Promise.resolve(question)
      }
    default:
      return Promise.resolve(question)
  }
}
