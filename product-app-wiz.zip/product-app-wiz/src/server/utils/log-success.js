export default (log, message) => data => {
  log.info(message)
  return data
}
