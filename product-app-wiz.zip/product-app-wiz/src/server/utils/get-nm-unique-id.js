export default req => req.headers['x-nm-nm_uid'] || 'no_user'
