export default ({ data }) => data
