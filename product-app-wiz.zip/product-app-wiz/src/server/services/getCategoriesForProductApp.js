import { get } from 'axios'
import { services, domains } from 'config'
import { checkStatus, logSuccess, logError } from '../utils'

export const getCategoriesForProductApp = (headers, logger, productApplicationId) => {
  logger.info(`making request: ${domains.srcdq}${services.productAppQuestions}/${productApplicationId}/sectionCategories`)
  return get(`${domains.srcdq}${services.productAppQuestions}/${productApplicationId}/sectionCategories`, { logger, headers })
  .then(checkStatus)
  .then(response => response.data)
  .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET categories for product app success' }))
  .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET categories for product app failure'}))
}
