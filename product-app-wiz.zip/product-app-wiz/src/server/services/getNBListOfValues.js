import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'

export const getNBListOfValues = (headers, logger, listOfValueName) =>
    get(`${domains.newbusiness}${services.newbusinessCodePairs}/${listOfValueName}`, { logger, headers })
        .then(checkHttpStatus)
        .then(response => response.data)
        .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET NB List of values for product app success' }))
        .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET NB List of values for product app failure'}))
        .catch(logError(logger, {message: `Attempted URL: ${domains.newbusiness}${services.newbusinessCodePairs}/${listOfValueName}`}))
