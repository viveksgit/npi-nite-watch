import { get } from 'axios'
import { services, domains } from 'config'
import { checkStatus, logSuccess, logError } from '../utils'

export const getPdfUrl = (headers, logger, productAppId) => {
  return get(`${domains.srcpdfgen}${services.getforms}/${productAppId}`, {headers})
    .then(checkStatus)
    .then(response => response.data)
    .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET Pdf for product app success' }))
    .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET Pdf for product app failure'}))
}
