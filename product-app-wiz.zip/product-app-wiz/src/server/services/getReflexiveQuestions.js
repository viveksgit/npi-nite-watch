import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'

export const getReflexiveQuestions = (headers, logger, productApplicationId, sectionQuestionRelId, answer) =>
    get(`${domains.srcdq}${services.reflexiveQuestions}/reflexive-questions/${productApplicationId}?sectionQuestionRelId=${sectionQuestionRelId}&answer=${answer}`, { logger, headers })
        .then(checkHttpStatus)
        // .then(normalizeJson)
        .then(response => response.data)
        .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET reflexive questions for product app success' }))
        .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET reflexive questions for product app failure'}))
