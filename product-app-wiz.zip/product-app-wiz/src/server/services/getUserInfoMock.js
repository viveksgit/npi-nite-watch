export const getUserInfo = (headers, logger, upn) => {
  return Promise.resolve({nmUniqueId: 'LAUGHALITTLE'})
}
module.exports = getUserInfo
