import { get } from 'axios'
import { services, domains } from 'config'
import { checkStatus, logSuccess, logError } from '../utils'

export const getFinancialRepData = (headers, logger, frNmUniqueId) => get(`${domains.fr}${services.financialRepData}/${frNmUniqueId}`, { headers })
    .then(checkStatus)
    .then(response => response.data)
    .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET Financial rep data for product app success' }))
    .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET Financial rep data for product app failure'}))
