import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess } from '../utils'

const getUserInfo = (headers, logger, upn) => {
  const userInfoPromises = []
  userInfoPromises.push(
      get(`${domains.graph}${services.graphUsers}/${upn}`, { logger, headers })
    )

  userInfoPromises.push(
      get(`${domains.graph}${services.graphUsers}/${upn}/${services.graphMemberOf}`, { logger, headers })
    )

  return Promise.all(userInfoPromises)
      .then(promises => {
        const baseUserInfo = promises[0]
        const adMemberships = promises[1]

        const nmUniqueIdKey = Object.keys(baseUserInfo.data).find(key => (String(key).indexOf('extensionAttribute7') >= 0))

        const data = {
          fullName: baseUserInfo.data.displayName,
          department: baseUserInfo.data.department,
          email: baseUserInfo.data.mail,
          phone: baseUserInfo.data.telephoneNumber,
          principalName: baseUserInfo.data.userPrincipalName,
          nmUniqueId: baseUserInfo.data[nmUniqueIdKey],
          adGroups: adMemberships.data.value.map(element => { return { name: element.displayName} })
        }
        return data
      })
      .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET User info for product app success' }))
}

module.exports = getUserInfo
