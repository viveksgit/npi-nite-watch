import { post, put } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'

export const upsertAnswers = (headers, logger, body, productApplicationId) => {
  logger.info('Upserting answer for -> ', body.id)

  let upsertPromise = (body.id)
    ? put(`${domains.npirqa}${services.questions}/${productApplicationId}/answers/${body.id}`, body, { logger, headers })
    : post(`${domains.npirqa}${services.questions}/${productApplicationId}/answers`, body, { logger, headers })

  return upsertPromise
    .then(checkHttpStatus)
    .then(response => response.data)
    .then(logSuccess(logger, { message: '#product-app-wiz services::upsertAnswers [Success] - POST/PUT answers for product app success' }))
    .catch(logError(logger, {message: '#Product-app-wiz services::upsertAnswers [Error] - POST/PUT answers for product app failure'}))
    .catch(error => {
      if (error.response.status === 400) {
        return error.response.data
      }
      throw error
    })
}
