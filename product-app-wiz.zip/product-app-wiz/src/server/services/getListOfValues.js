import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'

export const getListOfValues = (headers, logger, listOfValueName) =>
    get(`${domains.srclov}${services.listOfValues}/${listOfValueName}`, { logger, headers })
        .then(checkHttpStatus)
        // .then(normalizeJson)
        .then(response => response.data)
        .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET List of values for product app success' }))
        .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET List of values for product app failure'}))
