import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'
import resolveQuestion from '../utils/resolveQuestion'

export const getQuestions = (headers, logger, productApplicationId, sectionId) =>
    get(`${domains.npirqa}${services.questions}/${productApplicationId}/questions?sectionId=${sectionId}`, { logger, headers })
        .then(checkHttpStatus)
        .then(response => {
          response.data = response.data.map((question) => resolveQuestion(headers, logger, question))
          return Promise.all(response.data)
            .then(response => response)
        })
        .then(logSuccess(logger, { message: '#product-app-wiz services::getQuestions [Success] - GET questions for product app success' }))
        .catch(logError(logger, {message: '#Product-app-wiz services::getQuestions [Error] - GET questions for product app failure'}))
