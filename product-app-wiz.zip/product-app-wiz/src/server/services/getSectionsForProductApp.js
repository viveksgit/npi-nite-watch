import { get } from 'axios'
import { services, domains } from 'config'
import { checkHttpStatus, logSuccess, logError } from '../utils'
import resolveQuestion from '../utils/resolveQuestion'

export const getSectionsForProductApp = (headers, logger, productApplicationId) =>
    get(`${domains.srcdq}${services.productAppQuestions}/${productApplicationId}/sections`, { logger, headers })
        .then(checkHttpStatus)
        .then(response => response.data)
        .then(logSuccess(logger, { message: '#product-app-wiz [Success] - GET sections for product app success' }))
        .catch(logError(logger, {message: '#Product-app-wiz [Error] - GET sections for product app failure'}))
