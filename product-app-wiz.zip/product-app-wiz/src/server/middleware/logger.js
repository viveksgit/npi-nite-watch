import log from 'nmlvhub-node-logger'

export default () => (req, res, next) => {
  const start = Date.now()
  req.log = log.child({
    requestPath: req.url,
    environment: process.env.NODE_APP_INSTANCE || process.env.NODE_ENV,
    correlationId: req.headers['x-nmlvhub-corid'],
    httpVerb: req.method,
    params: req.params,
    headers: req.headers,
    GIT_SHA: process.env.GIT_COMMIT
  })
  req.log.info('Request received')
  res.on('finish', () => {
    const duration = Date.now() - start
    req.log.info(`Service Response Time: ${duration}`)
  })
  return next()
}
