import jwtDecoder from 'jwt-decode'
import userInfoMock from '../services/getUserInfoMock'
import userInfoLive from '../services/getUserInfo'
const getUserInfo = (process.env.KUBERNETES_SERVICE_HOST) ? userInfoLive : userInfoMock

export default () => (req, res, next) => {
  console.log('loggedInUserInfoInjector() -->')
  const accessToken = req.get('access_token')
  if (accessToken) {
    console.log('loggedInUserInfoInjector() getting user info!')
    const decodedToken = jwtDecoder(req.get('access_token'))

    const loggedInUserInfo = getUserInfo({Authorization: accessToken, 'api-version': 1.6}, req.log, decodedToken.upn)
    .then(response => {
      req.headers['x-nm-app-user-info'] = response
      req.headers['x-nm-nm_uid'] = response.nmUniqueId
      return next()
    })
    .catch(error => next(error))
  } else {
    return next()
  }
}
