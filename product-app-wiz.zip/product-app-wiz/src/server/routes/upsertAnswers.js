import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'
import { upsertAnswers } from '../services/upsertAnswers'
import getHeaders from 'src-utils/src/util/getHeaders'

export default asyncFunc((req, res) => {
  const { body, log } = req
  try {
    const headers = getHeaders(req, 'npi-apps')
    const response = awaitFunc(upsertAnswers(headers, log, body, req.params.productApplicationId))
    if (response.fieldValidationErrors) {
      return res.status(400).json(response)
    } else {
      return res.status(200).json(response)
    }
    // req.log.info('response ->', response)
  } catch (err) {
    req.log.error({
      message: '#Product-app-wiz [Error] - PUT answers for product app failure',
      headers: req.headers,
      error: err.message,
      details: err.response.data
    })
    if (err.response.status === 400) {
      return res.status(400).json(err.response.data).end()
    } else {
      return res.status(500).json({message: err.response.msg}).end()
    }
  }
})
