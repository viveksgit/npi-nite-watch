import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'

import getHeaders from 'src-utils/src/util/getHeaders'

import { getNBListOfValues } from '../services/getNBListOfValues'

export default asyncFunc((req, res) => {
  const headers = getHeaders(req, 'npi-apps')

  try {
    const response = awaitFunc(getNBListOfValues(
      Object.assign({}, headers, {Accept: 'application/json'}),
            req.log,
            req.params.listOfValueName))
    const mappedResponse = response.map(lov => Object.assign({}, { type: req.params.listOfValueName, code: lov.code, text: lov.value}))
    return res.status(200).json(mappedResponse)
  } catch (err) {
    req.log.info({message: '#Product-app-wiz [Error] - GET NB List of Values is an issue!',
      headers: headers,
      errorMessage: err.message
    })
    return res.status(400).json({errorMessage: err.message}).end()
  }
})
