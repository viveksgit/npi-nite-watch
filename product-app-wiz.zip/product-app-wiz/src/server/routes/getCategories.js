import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'

import getHeaders from 'src-utils/src/util/getHeaders'

import { getCategoriesForProductApp } from '../services/getCategoriesForProductApp'

export default asyncFunc((req, res) => {
  const headers = getHeaders(req, 'npi-apps')
  req.log.info('Logged in user', headers.loggedInUserInfo)
  try {
    const response = awaitFunc(getCategoriesForProductApp(headers, req.log, req.params.productApplicationId))
    return res.status(200).json(response)
  } catch (err) {
    req.log.info({message: '#Product-app-wiz [Error] - GET categories for product app failure',
      headers: headers,
      errorMessage: err.message})
    return res.status(400).end()
  }
})
