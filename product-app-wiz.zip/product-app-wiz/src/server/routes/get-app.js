import React from 'react'
import reactDomServer from 'react-dom/server'

import { readFileSync } from 'fs'
import newrelic from 'newrelic'
import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'
import { basePath, domains, adal } from 'config'
import { getNmUniqueId, getHeaders, getUserName} from '../utils'
import Entry from './../../app/entry'
import createStore from './../../app/store/createStore'
import { getBrowser } from '../utils/getbrowser'

const clientConfig = { basePath }
const { assets } = domains

const mockTokens = (process.env.KUBERNETES_SERVICE_HOST)
? undefined
:  {
 accessToken: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyIsImtpZCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyJ9.eyJhdWQiOiJodHRwczovL2dyYXBoLndpbmRvd3MubmV0IiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvNmVkZGQxODUtN2FkNy00ZWUzLTk0ODEtMDQ2NDRiOWY0M2EyLyIsImlhdCI6MTUxNTA4MTU2NCwibmJmIjoxNTE1MDgxNTY0LCJleHAiOjE1MTUwODU0NjQsImFjciI6IjEiLCJhaW8iOiJBU1FBMi84R0FBQUE3TGZwQk5iSURFOTVwTm8vWnc1cjJDWjBMQWNDMkFMaGVkVzkxZHRjMnNNPSIsImFtciI6WyJ3aWEiXSwiYXBwaWQiOiJkNWM4Zjk1Zi0xM2Q0LTQyMmQtYjM1Yi1iZjllOTY0MGUxM2MiLCJhcHBpZGFjciI6IjAiLCJlX2V4cCI6MjYyODAwLCJmYW1pbHlfbmFtZSI6Ik1BVFVTWkFLIiwiZ2l2ZW5fbmFtZSI6Ik1BVFQiLCJpbl9jb3JwIjoidHJ1ZSIsImlwYWRkciI6IjIxNi4yMC4xNzYuNCIsIm5hbWUiOiJNQVRUIE1BVFVTWkFLIiwib2lkIjoiMTAzNTVhYWItNGZmMS00NzY1LTljMWQtMDk3ZTYzMjMwMDRjIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTEzNjM4ODIwMjAtMzA3NjQ1NjYwOC0yMjgwMDY2MDYyLTI0NzI2IiwicHVpZCI6IjEwMDM3RkZFOTQ4OTMyRkEiLCJzY3AiOiJHcm91cC5SZWFkLkFsbCBVc2VyLlJlYWQgVXNlci5SZWFkLkFsbCIsInN1YiI6IkVpbFMtNml0NVVaN0RzeF91aF9NQjNvNl9GakNDVVc2WERhaWFzTFZ2MUUiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiTkEiLCJ0aWQiOiI2ZWRkZDE4NS03YWQ3LTRlZTMtOTQ4MS0wNDY0NGI5ZjQzYTIiLCJ1bmlxdWVfbmFtZSI6Im1hdHRtYXR1c3pha0BubWNvcC5jb20iLCJ1cG4iOiJtYXR0bWF0dXN6YWtAbm1jb3AuY29tIiwidXRpIjoiV2VSNlpSVXVqMHVUeEpWT3I5UUhBQSIsInZlciI6IjEuMCJ9.dI5FOc9hJWMN0TzO1QFSbL_dma_bItINUb13qB-RHniy7IlqDB6hEG7Mje93QlXwD20vQ3fSuq1KKThXIbBLFoRrNQYoWBeIfHo6AgosNU2YcfQXcFfTBK-6qaC0WGFFTWk4XSny5jRfW6Ne7AO4tHSpy9w6ABUCn2bO5vcp3G_HlbKQOWrLagLTQTPZLpcuCjYuDiAETTlDCifIZRrnesFkPQaa4YEt0YydI59QIrSyPRUwKMOsQEng4gkXjEMfIz9sUImaeeu4OQGi2sKfAS-7PDjDV3irbt24S7QgBW8CWpsq6RB6nIek85zg5ZO6ZHEZvTrAyJ9CPw8vKvZoog',
 graphToken: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyIsImtpZCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyJ9.eyJhdWQiOiJkNWM4Zjk1Zi0xM2Q0LTQyMmQtYjM1Yi1iZjllOTY0MGUxM2MiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82ZWRkZDE4NS03YWQ3LTRlZTMtOTQ4MS0wNDY0NGI5ZjQzYTIvIiwiaWF0IjoxNTE1MDgxNTYyLCJuYmYiOjE1MTUwODE1NjIsImV4cCI6MTUxNTA4NTQ2MiwiYWlvIjoiWTJOZ1lQaDQ2MlI2cktxY3pmdU1CcDFOeTZ4WW1ka1VQS3V1Mzg1YXRVcE5XK010MXdNQSIsImFtciI6WyJ3aWEiXSwiZmFtaWx5X25hbWUiOiJNQVRVU1pBSyIsImdpdmVuX25hbWUiOiJNQVRUIiwiaW5fY29ycCI6InRydWUiLCJpcGFkZHIiOiIyMTYuMjAuMTc2LjQiLCJuYW1lIjoiTUFUVCBNQVRVU1pBSyIsIm5vbmNlIjoiYmViZjRjZjMtYzMzYS00ZjU0LTlmNmEtN2JiNzQ0ZGM5NmZjIiwib2lkIjoiMTAzNTVhYWItNGZmMS00NzY1LTljMWQtMDk3ZTYzMjMwMDRjIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTEzNjM4ODIwMjAtMzA3NjQ1NjYwOC0yMjgwMDY2MDYyLTI0NzI2Iiwic3ViIjoiUW5uZGszRnBvUVdicVhDVUJvemZJRy1uUFNxZ1R5b2VnWTc5RHNqUkttMCIsInRpZCI6IjZlZGRkMTg1LTdhZDctNGVlMy05NDgxLTA0NjQ0YjlmNDNhMiIsInVuaXF1ZV9uYW1lIjoibWF0dG1hdHVzemFrQG5tY29wLmNvbSIsInVwbiI6Im1hdHRtYXR1c3pha0BubWNvcC5jb20iLCJ1dGkiOiJXZVI2WlJVdWowdVR4SlZPZzlRSEFBIiwidmVyIjoiMS4wIn0.OZcouZ5wKcYtXJ36nVV4kR1jqC0Ca_X-O73gYq0A2ijtqyFgwK-ENaqYb7tbHuV5hQPSV_ldJBnQFRxmqPSRs-IB6HtAJgRLL-3f6FBFuwoWEJeQBSEd9VA0g-rYMu_klUwVOFX4OIAmUCqP1bnv2WNITsY1vs1lehklsuA2ZmKFAhbwe02h3vKB7jAF9XhDzODjKs0pX096yuQUOCA6DEi3kuUUrKTepLykGHzpUkyr3qoLSdHddCXo0i7xFRmGTd_maZGxC3Zb2bmyjJTMtPXfduT2UNCD9OWhw4XmLRCLvYLp0homlFL_9S_L6L8XDIeTu-gS2CJLmUhJRDWpWA'
}

const createPreloadedState = (nmUniqueId, userName) => ({
  meta: {
    title: '/product-app-wiz',
    nmUniqueId,
    userName
  }
})

const AppShell = ({ jsxString, state, assetManifest, newrelicJS, csrfToken, clientConfig, ua }) => {
  const cssUrl = assetManifest.app.css
  const jsUrl = assetManifest.app.js

  return `<!DOCTYPE html>
  <html>
    <head>
      <title>${state.meta.title}</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="mobile-web-app-capable" content="yes">
      <meta name="theme-color" content="#0090F9">
      ${cssUrl ? `<link rel="stylesheet" media="all" href="${assets}${cssUrl}">` : ''}
      ${newrelicJS}
      <script>
      const adal = '${JSON.stringify(adal)}'
      window.__CONFIG__ = ${JSON.stringify(clientConfig)};
      window.__EXTRA_CONFIG__ = ${JSON.stringify(mockTokens)}
      window._csrf = '${csrfToken}';
      function loadScript(url, callback) {
          callback = callback || function(){};
          var script = document.createElement('script');
          script.onload = callback;
          script.async = false;
          script.src = url;
          document.head.appendChild(script);
      }

      </script>
      <link rel="icon" href="${basePath}/assets/public/favicon.ico">
    </head>
    <body>
      <div id="app">${jsxString}</div>
      <script>window.__STATE__=${JSON.stringify(state).replace(/</g, '\\u003c')}</script>
      <script>
        ${ua.ie} ? loadScript('${basePath}/assets/public/polyfills.min.js'): '';
        loadScript('${assets}${jsUrl}');
      </script>
    </body>
  </html>`
}

// TODO: figure out how to refactor to not use let
let assetManifest

export default asyncFunc((req, res, next) => {
  try {
    const newrelicJS = newrelic.getBrowserTimingHeader()

    const nmUniqueId = getNmUniqueId(req)
    const userName = getUserName(req)
    const ua = getBrowser(req)
    // const headers = getHeaders(req)

    const store = createStore(createPreloadedState(nmUniqueId, userName))

    const state = store.getState()

    const jsxString = reactDomServer.renderToString(<Entry />)

    const csrfToken = req.csrfToken()

    if (!assetManifest) {
      assetManifest = JSON.parse(readFileSync('./build/public/assets.json'))
    }

    const html = AppShell({
      assetManifest,
      clientConfig,
      state,
      newrelicJS,
      csrfToken,
      jsxString,
      ua
    })

    res.set({
      Link:
        '<https://uitk.learnvest.com>; rel=dns-prefetch, <https://media.nmfn.com>; rel=dns-prefetch'
    })

    return res.send(html)
  } catch (err) {
    req.log.info({message: '#Product-app-wiz [Error] - get-app failure',
      headers: req.headers,
      errorMessage: err.message})
    return next(err)
  }
})
