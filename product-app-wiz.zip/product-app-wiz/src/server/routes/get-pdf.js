import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'
import getHeaders from 'src-utils/src/util/getHeaders'
import { getPdfUrl } from '../services/getPdfUrl'

export default asyncFunc((req, res) => {
  try {
    const headers = getHeaders(req, 'npi-apps')
    const response = awaitFunc(getPdfUrl(headers, req.log, req.params.productAppId))
    if (response.url) {
      return res.status(200).json(response)
    }
  } catch (err) {
    req.log.info({
      message: '#Product-app-wiz [Error] - GET pdf url for product app failure',
      headers: req.headers,
      error: err.message
    })
    return res.status(400).end()
  }
})
