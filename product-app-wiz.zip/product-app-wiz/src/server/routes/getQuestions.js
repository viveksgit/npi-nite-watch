import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'
import getHeaders from 'src-utils/src/util/getHeaders'
import { getQuestions } from '../services/getQuestions'

export default asyncFunc((req, res) => {
  const headers = getHeaders(req, 'npi-apps')

  try {
    req.log.info(`Retrieving questions for ${req.params.productApplicationId} for section ${req.params.sectionId}`)
    const response = awaitFunc(getQuestions(
            headers,
            req.log,
            req.params.productApplicationId,
            req.params.sectionId))
    return res.status(200).json(response)
  } catch (err) {
    req.log.info({message: `#Product-app-wiz router::getQuestions  [Error] - GET questions for product app failure`,
      headers: headers,
      errorMessage: err.message})
    return res.status(400).end()
  }
})
