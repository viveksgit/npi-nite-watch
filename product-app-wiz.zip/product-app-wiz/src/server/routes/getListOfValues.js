import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'

import getHeaders from 'src-utils/src/util/getHeaders'

import { getListOfValues } from '../services/getListOfValues'

export default asyncFunc((req, res) => {
  const headers = getHeaders(req, 'npi-apps')

  try {
    const response = awaitFunc(getListOfValues(
            headers,
            req.log,
            req.params.listOfValueName))
    return res.status(200).json(response)
  } catch (err) {
    req.log.info({message: '#Product-app-wiz [Error] - GET list of values for product app failure',
      headers: headers,
      errorMessage: err.message})
    return res.status(400).end()
  }
})
