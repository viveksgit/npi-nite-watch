import asyncFunc from 'asyncawait/async'
import awaitFunc from 'asyncawait/await'
import getHeaders from 'src-utils/src/util/getHeaders'
import { getReflexiveQuestions } from '../services/getReflexiveQuestions'

export default asyncFunc((req, res) => {
  const headers = getHeaders(req, 'npi-apps')
  req.log.info('params:', req.params.productApplicationId, req.query.sectionQuestionRelId, req.query.answer)
  try {
    const response = awaitFunc(getReflexiveQuestions(
            headers,
            req.log,
            req.params.productApplicationId,
            req.query.sectionQuestionRelId,
            req.query.answer))
    return res.status(200).json(response)
  } catch (err) {
    req.log.info({message: '#Product-app-wiz [Error] - GET reflexive questions for product app failure',
      headers: headers,
      errorMessage: err.message})
    return res.status(400).end()
  }
})
