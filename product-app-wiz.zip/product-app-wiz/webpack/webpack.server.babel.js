import path from 'path'
import CleanWebpackPlugin from 'clean-webpack-plugin'
import nodeExternals from 'webpack-node-externals'
const fileRoot = process.cwd()

const serverPack = {
  target: 'node',
  entry: './src/server/index.js',
  output: {
    path: path.join(fileRoot, '/build/server'),
    filename: 'server.js'
  },
  externals: [nodeExternals()], // do not attempt to bundle node_modules
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: /node_modules/
      }
    ]
  },
  plugins: [
    new CleanWebpackPlugin([path.join(fileRoot, 'build/server')], {
      root: path.join(__dirname, '../'),
      verbose: false
    })
  ]
}

module.exports = serverPack
