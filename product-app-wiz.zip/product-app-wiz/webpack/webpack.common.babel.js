import path from 'path'
import webpack from 'webpack'
import CleanWebpackPlugin from 'clean-webpack-plugin'
import AssetsPlugin from 'assets-webpack-plugin'
import CopyWebpackPlugin from 'copy-webpack-plugin'

const fileRoot = process.cwd()
const modules = ['src', 'node_modules']

module.exports = {
  entry: {
    app: ['./src/app/index.js', './src/app/styles/entry.scss']
  },
  module: {
    rules: [
      {
        test: /.js$/,
        loader: 'babel-loader',
        include: path.join(fileRoot, 'src/app')
      }
    ]
  },

  plugins: [
    new CleanWebpackPlugin([path.join(fileRoot, 'build/public')], {
      root: path.join(__dirname, '../'),
      verbose: false
    }),
    new CopyWebpackPlugin([{ from: 'src/app/static/' }]),
    new AssetsPlugin({
      filename: 'assets.json',
      path: path.join(fileRoot, '/build/public')
    })
  ],

  output: {
    filename: '[name].[hash].js',
    path: path.resolve(fileRoot, 'build/public')
  }
}
