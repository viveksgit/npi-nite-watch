function StatusWebpackPlugin () {}

StatusWebpackPlugin.prototype.apply = compiler => {
  compiler.plugin('compile', () => {
    setTimeout(() => {
      console.log('👾 Client 👾 : 👾 👾 👾 👾 👾 👾 👾 👾 👾')
    }, 0)
  })
  compiler.plugin('emit', (compilation, callback) => {
    // console.log('Client: webpack is going to emit files...')
    callback()
  })
  compiler.plugin('done', () => {
    setTimeout(() => {
      console.log(
        '🔥 Client 🔥 : 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥 '
      )
    }, 0)
  })
}

module.exports = StatusWebpackPlugin
