import UglifyJsPlugin from 'uglifyjs-webpack-plugin'
import { basePath, assetPath } from 'config'
import path from 'path'
import glob from 'glob-all'

import webpack from 'webpack'
import merge from 'webpack-merge'
import ExtractTextPlugin from 'extract-text-webpack-plugin'
import PurifyCSSPlugin from 'purifycss-webpack'
import common from './webpack.common.babel'
import uglifyConf from './uglify.json'

const fileRoot = process.cwd()
const modules = ['src', 'node_modules']

const prodPack = merge(common, {
  module: {
    rules: [
      {
        test: /.s?css$/,
        include: [path.join(fileRoot, 'src/app'), path.resolve(fileRoot, 'node_modules')],
        use: ExtractTextPlugin.extract({
          fallback: 'style-loader',
          use: [
            {
              loader: 'css-loader',
              options: {
                sourceMap: false,
                minimize: true
              }
            },
            {
              loader: 'postcss-loader',
              options: {
                sourceMap: false,
                plugins: loader => [
                  require('postcss-import')({ root: loader.resourcePath }),
                  require('postcss-cssnext')(),
                  require('cssnano')({ autoprefixer: { add: true } })
                ]
              }
            },
            {
              loader: 'sass-loader',
              options: {
                sourceMap: false,
                includePaths: modules
              }
            }
          ],
          // use style-loader in development
          fallback: 'style-loader'    // eslint-disable-line no-dupe-keys
        }),
        include: path.join(fileRoot, 'src')   // eslint-disable-line no-dupe-keys
      }
    ]
  },
  plugins: [
    new UglifyJsPlugin(uglifyConf),
    new webpack.LoaderOptionsPlugin({
      minimize: true,
      debug: false
    }),
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('production')
    }),
    new ExtractTextPlugin({
      filename: '[name].[contenthash].css'
    }),
    new PurifyCSSPlugin({
      paths: glob.sync([
        path.join(fileRoot, 'src/app/components/*.js'),
        path.join(fileRoot, 'src/app/components/*/*.js'),
        path.join(fileRoot, 'src/app/components/*/*/*.js'),
        path.join(fileRoot, 'src/app/components/*/*/*/*.js'),
        path.join(fileRoot, 'src/server/routes/get-app.js')
      ]),
      minimize: true
    })
  ],
  output: {
    publicPath: `${basePath}${assetPath}/`
  },
  performance: {
    hints: 'warning'
  }
})

module.exports = prodPack
