import path from 'path'
import webpack from 'webpack'
// import { BundleAnalyzerPlugin } from 'webpack-bundle-analyzer'
import { basePath, assetPath } from 'config'
import common from './webpack.common.babel'
import merge from 'webpack-merge'
import StatusPlugin from './status-webpack-plugin'

const fileRoot = process.cwd()

const devConfig = merge(
  {
    entry: {
      app: [
        'react-hot-loader/patch',
        'webpack-dev-server/client?http://localhost:3000',
        'webpack/hot/only-dev-server'
      ]
    },
    // devtool: 'cheap-module-source-map',  // may speed up rebuild but no source maps
    devtool: 'eval-source-map', // source maps
    devServer: {
      contentBase: path.join(fileRoot, 'dist'),
      hot: true,
      port: 3000,
      open: false,
      headers: { 'Access-Control-Allow-Origin': '*' },
      stats: 'minimal'
    },
    module: {
      rules: [
        {
          test: /.s?css$/,
          include: [path.join(fileRoot, 'src/app'), path.resolve(fileRoot, 'node_modules')],
          use: [
            {
              loader: 'style-loader' // creates style nodes from JS strings
            },
            {
              loader: 'css-loader' // translates CSS into CommonJS
            },
            {
              loader: 'postcss-loader',
              options: {
                plugins: loader => [
                  require('postcss-import')({ root: loader.resourcePath }),
                  require('postcss-cssnext')()
                ]
              }
            },
            {
              loader: 'sass-loader' // compiles Sass to CSS
            }
          ],
          include: path.join(fileRoot, 'src')   // eslint-disable-line no-dupe-keys
        }
      ]
    },
    plugins: [
      new webpack.HotModuleReplacementPlugin(),
      new StatusPlugin()
      // new BundleAnalyzerPlugin() // enable for the bundle analyzer to show in browser
    ],

    output: {
      publicPath: `http://localhost:3000${basePath}${assetPath}`
    }
  },
  common
)

module.exports = devConfig
