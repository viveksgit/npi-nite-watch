/* global test, expect */
import React from 'react'
import Banner from './../src/app/components/banner'
import renderer from 'react-test-renderer'

test('Banner Snapshot Test', () => {
  const component = renderer.create(<Banner text='Text' subtext='Sub' />)
  const tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})
