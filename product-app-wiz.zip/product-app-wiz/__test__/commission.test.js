/* global test, expect */
import React from 'react'
import {mount} from 'enzyme'
import Commission from './../src/app/components/question/types/complex/Commission'
import renderer from 'react-test-renderer'

describe('Commission test', () => {   // eslint-disable-line no-undef
  const config = {
    answer: {
      code: 1,
      frKeys: [{
        dsbNumber: '00000C4543',
        legalEntityId: 20278982,
        legalEntitySourceCode: 10,
        nmUniqueId: 'FQEBHG0E0',
        percentInterest: '100'
      }],
      id: 13,
      sectionQuestionRelId: 41
    },
    frsData: [{
      nmUniqueId: 'FQEBHG0E0',
      personalName: 'Craig Quinlan',
      noNum: '00003',
      telephoneAreaCode: '415',
      telephoneExtension: '',
      telephoneNumber: '733',
      telephoneUniqueNumber: '6555'
    }],
    answerId: 13,
    appId: 13,
    questionId: 1,
    questionName: 'commissionCredits',
    questionText: 'Commission Credits',
    questionTypeText: 'COMMISSION',
    reflexive: 1,
    sectionId: 1,
    sectionQuestionRelId: 41
  }

  test.skip('Commission component Snapshot Test', () => {
    const component = renderer.create(<Commission config={config} productApplicationId={13} />)
    const tree = component.toJSON()
    expect(tree).toMatchSnapshot()
  })

  test.skip('Commission component event Test', () => {
    const wrapper = mount(<Commission config={config} productApplicationId={13} />)
    wrapper.mount() // trigger the componentDidMount()
    const percentInterestInput = wrapper.find('[name="percentInterest"]')  // select the person interest text box
    percentInterestInput.simulate('blur')
    expect(percentInterestInput.props().value).toEqual('100')

    percentInterestInput.simulate('change', {target: {value: '50'}})
    percentInterestInput.simulate('blur')
    expect(percentInterestInput.props().value).toEqual('50')
  })
})
